const { Schema, model } = require("mongoose");

const PlaylistSchema = new Schema({
  Username: { type: String, required: false },
  UserId: { type: String, required: true },
  PlaylistName: { type: String, required: true },
  Playlist: { type: Array, required: true },
  CreatedOn: { type: Number, required: true },
});

// Compound unique index to prevent same user from creating duplicate playlists
PlaylistSchema.index({ UserId: 1, PlaylistName: 1 }, { unique: true });

module.exports = model("Playlist", PlaylistSchema);
