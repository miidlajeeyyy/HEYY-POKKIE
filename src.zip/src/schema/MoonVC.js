const mongoose = require("mongoose");

const PookieVCSchema = new mongoose.Schema({
  guildId: String,
  channelId: String,
  type: String,        // solo / duo / trio / squad / quintet
  categoryId: String,
});

module.exports = mongoose.models.PookieVC || mongoose.model("PookieVC", PookieVCSchema);
