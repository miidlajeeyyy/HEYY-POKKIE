const mongoose = require("mongoose");

const countingSchema = new mongoose.Schema({
    Guild: { type: String, required: true },
    Channel: { type: String, required: true },

    Count: { type: Number, default: 0 },
    LastUser: { type: String, default: null },

    FailReset: { type: Boolean, default: false },   // reset on wrong number
    DoubleCount: { type: Boolean, default: false }  // same user twice
});

module.exports = mongoose.models.Counting || mongoose.model("Counting", countingSchema);
