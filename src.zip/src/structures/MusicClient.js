/** @format */

const {
  Client,
  GatewayIntentBits,
  Collection,
  Partials,
} = require("discord.js");

const { Kazagumo, Plugins } = require("kazagumo");
const mongoose = require("mongoose");
const { Connectors } = require("shoukaku");
const Spotify = require("kazagumo-spotify");

// FIXED HYBRID SHARDING

const { AutoPoster } = require("topgg-autoposter");

const loadPlayerManager = require("../loaders/loadPlayerManager");
const permissionHandler = require("../events/Client/PremiumChecks");

const ShoukakuOptions = {
  moveOnDisconnect: false,
  resume: false,
  resumeTimeout: 30,
  reconnectTries: 2,
  restTimeout: 10000,
  userAgent: "Arrkiii",
};

class MusicBot extends Client {
  constructor() {
    super({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
      ],

      partials: [
        Partials.User,
        Partials.Channel,
        Partials.Message,
        Partials.GuildMember,
        Partials.Reaction,
      ],

      allowedMentions: {
        parse: ["roles", "users", "everyone"],
        repliedUser: false,
      },

      failIfNotExists: false,

      ws: {
        properties: {
          browser: "Discord Android",
        },
      },
    });

    /* -------------------- HYBRID SHARDING -------------------- */

    // FIXED
    // REMOVED getInfo()
   

    /* -------------------- COLLECTIONS -------------------- */

    this.commands = new Collection();
    this.slashCommands = new Collection();
    this.aliases = new Collection();
    this.cooldowns = new Collection();

    /* -------------------- CONFIG -------------------- */

    this.config = require("../config.js");

    this.owners = Array.from(
      new Set([this.config.ownerID, ...(this.config.ownerIDs || [])].filter(Boolean)),
    );
    this.owner = this.owners[0] || this.config.ownerID;
    this.prefix = this.config.prefix;
    this.topgg = this.config.topgg;
    this.embedColor = this.config.embedColor;

    this.button = require("../custom/button.js");
    this.embed = require("../custom/embed.js")(this.embedColor);

    require("../custom/numformat")(this);

    this.logger = require("../utils/logger.js");
    this.emoji = require("../utils/emoji.json");

    this.manager = null;

    this.spamMap = new Map();

    if (!this.token) {
      this.token = this.config.token;
    }

    /* -------------------- DATABASE -------------------- */

    this._connectMongodb();

    /* -------------------- TOP.GG -------------------- */

    this._initAutoPoster();

    /* -------------------- PREMIUM -------------------- */

    permissionHandler(this);

    /* -------------------- PLAYER -------------------- */

    loadPlayerManager(this);

    /* -------------------- LOADERS -------------------- */

    [
      "loadAntinukes",
      "loadAutoMods",
      "loadClients",
      "loadCommands",
      "loadNodes",
      "loadSlashCommands",
      "loadPlayers",
    ].forEach((handler) => {
      try {
        require(`../loaders/${handler}`)(this);
        console.log(`✅ Loaded ${handler}`);
      } catch (err) {
        console.log(`❌ Failed ${handler}`, err);
      }
    });
  }

  /* -------------------- MONGODB -------------------- */

  async _connectMongodb() {
    try {
      const dbOptions = {
        autoIndex: false,
        connectTimeoutMS: 30000,
        socketTimeoutMS: 30000,
        family: 4,
      };

      mongoose.set("strictQuery", false);

      await mongoose.connect(this.config.mongourl, dbOptions);

      this.logger.log("[DB] Database connected", "ready");
    } catch (err) {
      console.log("MongoDB Error:", err);
    }

    mongoose.connection.on("connected", () => {
      this.logger.log("[DB] Database connected", "ready");
    });

    mongoose.connection.on("error", (err) => {
      this.logger.log(
        `[DB] Mongoose connection error: ${err.stack}`,
        "error"
      );
    });

    mongoose.connection.on("disconnected", () => {
      this.logger.log("[DB] Mongoose disconnected", "error");
    });
  }

  /* -------------------- TOP.GG AUTPOSTER -------------------- */

  _initAutoPoster() {
    try {
      const topggToken = this.config.topgg;

      if (!topggToken) {
        this.logger.log("Top.gg API token is not set.", "error");
        return;
      }

      AutoPoster(topggToken, this)
        .on("posted", () => {
          this.logger.log("Posted stats to top.gg!", "ready");
        })
        .on("error", (err) => {
          this.logger.log(
            `Error posting stats to top.gg: ${err}`,
            "error"
          );
        });
    } catch (err) {
      console.log("TopGG Error:", err);
    }
  }

  /* -------------------- LOGIN -------------------- */

  connect() {
    return super.login(this.token);
  }
}

module.exports = MusicBot;