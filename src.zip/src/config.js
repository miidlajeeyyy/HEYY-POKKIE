/** @format */
module.exports = {
  token: "MTQ5ODU3ODU2OTcwMDMxMTA4MQ.GqMWZZ.NpdYvSM7Fft42G8zLHc88-KOUvP9Sw9o35rKOU",
  clientId: "1498578569700311081",
  prefix: ".",
  embedColor: "#8806CE",
  ownerID: "1130416772168818748",
  ownerIDs: ["1130416772168818748", "1130416772168818748"],
  SpotifyID: "7e701486298046ee84e6ec9b27dbe8e8",
  SpotifySecret: "a49750f2141f413d870a4c0cfef54192",
  mongourl: "mongodb+srv://kmczackyt_db_user:hadihaneen@moon.5l8qhne.mongodb.net/?appName=Moon",
  logs: "https://discord.com/api/webhooks/1437094339602813110/YDBHeNCjwuV4TQsp4FjZ3kAgDjEanzEuV3tyYwIURDFzcJgEjWPqcuMc5BUt1mLt9Qaf",
  node_source: "ytsearch",
  topgg: "",
  links: {
    BG: "https://cdn.discordapp.com/attachments/1435659292047835257/1447417963157127220/IMG-20251207-WA0001.gif?ex=69378c86&is=69363b06&hm=35073334e256d4022f335d8cc33cc9338021bbedc1f81d9cfc20bc10d814b004",    arrkiii: "https://cdn.discordapp.com/attachments/1435659292047835257/1447417963157127220/IMG-20251207-WA0001.gif?ex=69378c86&is=69363c06&hm=35073334e256d4022f335d8cc33cc9338021bbedc1f81d9cfc20bc10d814b004",    support: "https://discord.gg/B8E3QgWYA",
    invite: "https://discord.com/oauth2/authorize?client_id=1498578569700311081",
    power: "Pookie<3",
    vanity: "discord.gg/urV9mkfW9t",
    guild: "1325384856477368420",
    topgg: "",
  },
  Webhooks: {
    black: "https://discord.com/api/webhooks/1506988643305394238/9IiA0-VNcONzGOfYhJpzi59eZ6Ryxm1qHDxxup1X6p4ba_zAKADgy_osFaJxGLF8M8FT",
    player_create: "https://discord.com/api/webhooks/1506988643305394238/9IiA0-VNcONzGOfYhJpzi59eZ6Ryxm1qHDxxup1X6p4ba_zAKADgy_osFaJxGLF8M8FT",
    player_delete: "https://discord.com/api/webhooks/1506988643305394238/9IiA0-VNcONzGOfYhJpzi59eZ6Ryxm1qHDxxup1X6p4ba_zAKADgy_osFaJxGLF8M8FT",
    guild_join: "https://discord.com/api/webhooks/1506988643305394238/9IiA0-VNcONzGOfYhJpzi59eZ6Ryxm1qHDxxup1X6p4ba_zAKADgy_osFaJxGLF8M8FT",
    guild_leave: "https://discord.com/api/webhooks/1506988643305394238/9IiA0-VNcONzGOfYhJpzi59eZ6Ryxm1qHDxxup1X6p4ba_zAKADgy_osFaJxGLF8M8FT",
    cmdrun: "https://discord.com/api/webhooks/1506988643305394238/9IiA0-VNcONzGOfYhJpzi59eZ6Ryxm1qHDxxup1X6p4ba_zAKADgy_osFaJxGLF8M8FT",
  },
  // 🔥 Updated Lavalink Node
  nodes: [
    {
      url: process.env.NODE_URL || "hyperion.kythia.xyz:3010",
      name: process.env.NODE_NAME || "paku",
      auth: process.env.NODE_AUTH || "dsc.gg/kythia",
      secure: parseBoolean(process.env.NODE_SECURE || "false"),
    },
  ],
};

function parseBoolean(value) {
  if (typeof value === "string") {
    value = value.trim().toLowerCase();
  }
  switch (value) {
    case true:
    case "true":
      return true;
    default:
      return false;
  }
}
