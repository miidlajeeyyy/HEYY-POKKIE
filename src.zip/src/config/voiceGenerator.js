module.exports = {
  generators: {
    '୨🔒୧・𝑱𝑶𝑰𝑵 𝟐 𝑪𝑹𝑬𝑨𝑻𝑬 (𝑷𝑹𝑽𝑻 𝑽𝑪)': {
      '・ 🍸 ・ General ・ ん': 20,
        '・ 🍸 ・ Solo ・ ん': 1,
      '・ 🍸 ・ Duo ・ ん': 2,
      '・ 🍸 ・ Trio ・ ん': 3,
      '・ 🍸 ・ Squad ・ ん': 4,
    },
  },
  status: {
    enabled: true,
    format: '{type} VC • {count}/{limit}',
  }
};
