module.exports = {
  name: "tlock",
  aliases: [],
  category: "Ticket",
  description: "Lock the ticket (only staff can talk)",
  usage: "tlock",

  execute: async (message) => {
    if (!message.channel.name?.startsWith?.("ticket-")) return message.reply("❌ Use this inside a ticket channel.");
    const admin = message.guild.roles.cache.find(r => r.name === "Ticket Admin");
    const manager = message.guild.roles.cache.find(r => r.name === "Ticket Manager");
    if (!admin || !manager) return message.reply("❌ Ticket roles not found.");
    if (!message.member.roles.cache.has(admin.id) && !message.member.roles.cache.has(manager.id)) return message.reply("❌ You don't have permission.");

    // Deny SEND_MESSAGES for @everyone
    await message.channel.permissionOverwrites.edit(message.guild.id, { SendMessages: false }).catch(() => {});
    message.reply("🔐 Ticket locked — only staff can send messages now.");
  }
};
