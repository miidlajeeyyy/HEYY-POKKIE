module.exports = {
  name: "tremove",
  aliases: [],
  category: "Ticket",
  description: "Remove a user from the ticket channel",
  usage: "tremove @user",

  execute: async (message, args) => {
    if (!message.channel.name?.startsWith?.("ticket-")) return message.reply("❌ This command can only be used inside a ticket channel.");
    const admin = message.guild.roles.cache.find(r => r.name === "Ticket Admin");
    const manager = message.guild.roles.cache.find(r => r.name === "Ticket Manager");
    if (!admin || !manager) return message.reply("❌ Ticket roles not found.");
    if (!message.member.roles.cache.has(admin.id) && !message.member.roles.cache.has(manager.id)) return message.reply("❌ You don't have permission.");

    const user = message.mentions.members.first();
    if (!user) return message.reply("❌ Mention a user: `>tremove @user`");

    await message.channel.permissionOverwrites.edit(user.id, {
      ViewChannel: false,
      SendMessages: false
    }).catch(err => { return message.reply("❌ Failed to remove member."); });

    message.reply(`❎ Removed **${user.user.tag}** from this ticket.`);
  }
};
