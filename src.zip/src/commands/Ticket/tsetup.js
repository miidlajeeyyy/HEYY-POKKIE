const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionsBitField,
  ChannelType,
} = require("discord.js");

const PANEL_IMAGE =
      "https://cdn.discordapp.com/attachments/1434613321100955768/1459684008274165800/text_only.png?ex=69642c2b&is=6962daab&hm=8c366e5828c81d8ba617d341fb6629f47af23fe31ce552aac7c5012565db4b77";
const EMBED_COLOR = "#8806ce";

module.exports = {
  name: "tsetup",
  aliases: [],
  category: "Ticket",
  userPerms: ["Administrator"],
  description: "Setup the ticket system and send ticket panel",
  usage: "tsetup <#channel>",

  execute: async (message, args, client) => {
    if (!message.guild) return message.reply("❌ Use this command in a server!");
    const panelChannel = message.mentions.channels.first();
    if (!panelChannel) return message.reply("❌ Please mention a channel to send the ticket panel. Example: `>tsetup #support`");

    // create roles
    const adminRoleName = "Ticket Admin";
    const managerRoleName = "Ticket Manager";
    let adminRole = message.guild.roles.cache.find(r => r.name === adminRoleName);
    let managerRole = message.guild.roles.cache.find(r => r.name === managerRoleName);

    if (!adminRole) adminRole = await message.guild.roles.create({ name: adminRoleName, reason: "Ticket system role (admin)" });
    if (!managerRole) managerRole = await message.guild.roles.create({ name: managerRoleName, reason: "Ticket system role (manager)" });

    // create category
    let ticketCategory = message.guild.channels.cache.find(c => c.name === "Tickets" && c.type === ChannelType.GuildCategory);
    if (!ticketCategory) {
      ticketCategory = await message.guild.channels.create({
        name: "Tickets",
        type: ChannelType.GuildCategory,
        permissionOverwrites: [
          { id: message.guild.id, deny: [PermissionsBitField.Flags.ViewChannel] }
        ]
      });
    }

    // text channel creator
   async function ensureTextChannel(name) {
  let ch = message.guild.channels.cache.find(
    c => c.name === name && c.type === ChannelType.GuildText
  );

  if (!ch) {
    ch = await message.guild.channels.create({
      name,
      type: ChannelType.GuildText,
      permissionOverwrites: [
        {
          id: message.guild.id,
          deny: [PermissionsBitField.Flags.ViewChannel],
        },
        {
          id: message.guild.members.me.id,
          allow: [
            PermissionsBitField.Flags.ViewChannel,
            PermissionsBitField.Flags.SendMessages,
            PermissionsBitField.Flags.AttachFiles,
            PermissionsBitField.Flags.ReadMessageHistory,
          ],
        },
      ],
    });
  }

  return ch;
}

    const logsChannel = await ensureTextChannel("ticket-logs");
    const transcriptsChannel = await ensureTextChannel("ticket-transcripts");

    // panel embed
    const panelEmbed = new EmbedBuilder()
      .setTitle("🎟️ Support Tickets")
      .setDescription("Click the button below to create a ticket.\nStaff will assist you shortly.")
      .setColor(EMBED_COLOR)
      .setImage(PANEL_IMAGE);

    const panelRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("create_ticket_btn").setLabel("Create Ticket").setStyle(ButtonStyle.Primary)
    );

    await panelChannel.send({ embeds: [panelEmbed], components: [panelRow] });
    await message.reply({
      content: `✅ Ticket panel sent in ${panelChannel}\nRoles: ${adminRole} ${managerRole}\nChannels ensured: ${logsChannel} ${transcriptsChannel}`
    });
  }
};

    