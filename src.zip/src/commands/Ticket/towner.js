module.exports = {
  name: "towner",
  aliases: [],
  category: "Ticket",
  description: "Change ticket owner to another user",
  usage: "towner @user",

  execute: async (message, args) => {
    if (!message.channel.name?.startsWith?.("ticket-")) return message.reply("❌ Use this inside a ticket channel.");
    const admin = message.guild.roles.cache.find(r => r.name === "Ticket Admin");
    const manager = message.guild.roles.cache.find(r => r.name === "Ticket Manager");
    if (!admin || !manager) return message.reply("❌ Ticket roles not found.");
    if (!message.member.roles.cache.has(admin.id) && !message.member.roles.cache.has(manager.id)) return message.reply("❌ You don't have permission.");

    const user = message.mentions.members.first();
    if (!user) return message.reply("❌ Mention the new owner: `>towner @user`");

    // remove previous owner overwrite(s)
    const overwrites = message.channel.permissionOverwrites.cache;
    for (const [id, perm] of overwrites) {
      // skip roles and @everyone; remove any user-specific ViewChannel allow (only if it's not a role)
      if (!message.guild.roles.cache.get(id) && id !== message.guild.id) {
        // set to false (remove view) unless it's the new owner
        if (id !== user.id) {
          await message.channel.permissionOverwrites.edit(id, { ViewChannel: false, SendMessages: false }).catch(() => {});
        }
      }
    }

    // add new owner
    await message.channel.permissionOverwrites.edit(user.id, { ViewChannel: true, SendMessages: true }).catch(() => {});
    // update topic owner:xxxxx
    await message.channel.setTopic(`owner:${user.id}`).catch(() => {});
    message.reply(`✅ ${user.user.tag} is now the ticket owner.`);
  }
};
