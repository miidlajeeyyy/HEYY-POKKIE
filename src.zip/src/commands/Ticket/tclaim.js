const { EmbedBuilder } = require("discord.js");
module.exports = {
  name: "tclaim",
  aliases: [],
  category: "Ticket",
  description: "Claim a ticket (command)",
  usage: "tclaim",

  execute: async (message, args, client) => {
    if (!message.channel.name?.startsWith?.("ticket-")) return message.reply("❌ Use this inside a ticket channel.");
    const admin = message.guild.roles.cache.find(r => r.name === "Ticket Admin");
    const manager = message.guild.roles.cache.find(r => r.name === "Ticket Manager");
    if (!admin || !manager) return message.reply("❌ Ticket roles not found.");
    if (!message.member.roles.cache.has(admin.id) && !message.member.roles.cache.has(manager.id)) return message.reply("❌ You don't have permission.");

    const embed = new EmbedBuilder()
      .setTitle("🙋 Ticket Claimed")
      .setDescription(`${message.author.tag} claimed this ticket`)
      .setColor("#8806ce")
      .setTimestamp();

    await message.channel.send({ embeds: [embed] });
    // logs
    const logsCh = message.guild.channels.cache.find(c => c.name === "ticket-logs");
    if (logsCh) await logsCh.send({ embeds: [embed] }).catch(() => {});
    message.reply({ content: "✅ You claimed the ticket.", ephemeral: true }).catch(() => {});
  }
};
