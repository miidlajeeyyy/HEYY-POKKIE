const { PermissionsBitField } = require("discord.js");

module.exports = {
  name: "tadd",
  aliases: [],
  category: "Ticket",
  description: "Add a user to the ticket channel",
  usage: "tadd @user",

  execute: async (message, args) => {
    if (!message.channel.name?.startsWith?.("ticket-")) return message.reply("❌ This command can only be used inside a ticket channel.");
    const admin = message.guild.roles.cache.find(r => r.name === "Ticket Admin");
    const manager = message.guild.roles.cache.find(r => r.name === "Ticket Manager");
    if (!admin || !manager) return message.reply("❌ Ticket roles not found.");
    if (!message.member.roles.cache.has(admin.id) && !message.member.roles.cache.has(manager.id)) return message.reply("❌ You don't have permission.");

    const user = message.mentions.members.first();
    if (!user) return message.reply("❌ Mention a user: `>tadd @user`");

    await message.channel.permissionOverwrites.edit(user.id, {
      ViewChannel: true,
      SendMessages: true,
      ReadMessageHistory: true
    }).catch(err => { return message.reply("❌ Failed to add member."); });

    message.reply(`✅ Added **${user.user.tag}** to this ticket.`);
  }
};
