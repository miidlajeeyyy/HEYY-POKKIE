const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "say",
  description: "Make the bot repeat your message",
  category: "utility",

  execute(message, args) {
    if (!args.length)
      return message.reply("❌ | You need to provide a message!");

    const text = args.join(" ");

    // Create confirmation embed
    const embed = new EmbedBuilder()
      .setDescription("**<:yes:1414559141468311562> | Message Sent**")
      .setColor("#8806CE");

    // Send embed and delete it after 5 seconds
    message.channel.send({ embeds: [embed] })
      .then(msg => setTimeout(() => msg.delete().catch(() => {}), 5000));

    // Send the normal text message
    message.channel.send(text);
  },
};
