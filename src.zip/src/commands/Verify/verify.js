const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionsBitField,
} = require("discord.js");
const Verify = require("../../schema/verifySchema");

module.exports = {
  name: "verifysetup",
  category: "Verify",
  userPermissions: ["Administrator"],

  execute: async (message, args) => {
    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator))
      return message.reply("❌ Admin only.");

    const channel =
      message.mentions.channels.first() ||
      message.guild.channels.cache.get(args[0]);
    const role =
      message.mentions.roles.first() ||
      message.guild.roles.cache.get(args[1]);

    if (!channel || !role)
      return message.reply("❌ Usage: `>verifysetup #channel @role`");

    await Verify.findOneAndUpdate(
      { guildId: message.guild.id },
      {
        guildId: message.guild.id,
        channelId: channel.id,
        roleId: role.id,
      },
      { upsert: true, new: true }
    );

    const embed = new EmbedBuilder()
      .setTitle("🔐 Server Verification")
      .setDescription("Click **Verify** and complete the CAPTCHA")
      .setColor("Green");

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("verify_button")
        .setLabel("Verify")
        .setStyle(ButtonStyle.Success)
    );

    await channel.send({ embeds: [embed], components: [row] });
    message.reply("✅ Verification setup complete.");
  },
};
