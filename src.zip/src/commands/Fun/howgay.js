const {
  EmbedBuilder,
  MessageFlags,
  ButtonBuilder,
  ActionRowBuilder,
  ButtonStyle,
} = require("discord.js");

module.exports = {
  name: "howgay",
  category: "Fun",
  aliases: ["gay"],
  cooldown: 3,
  description: "Shows How Member Gay Is!",
  args: false,
  usage: "howgay <Mention Member>",
  userPerms: [],
  owner: false,

  execute: async (message, args, client, prefix) => {
    const User = message.mentions.members.first();
    const gayrate = Math.floor(Math.random() * 101);

    if (!User) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("#8806CE")
            .setDescription(`___Please mention a user to check gay rate!___`),
        ],
      });
    }

    // ⭐ Add rainbow overlay image
    const avatarUrl = User.displayAvatarURL({ extension: "jpg", size: 512 });
    const rainbowImg = `https://some-random-api.com/canvas/gay?avatar=${avatarUrl}`;

    if (User.id === "1224711618638774286") {
      const owner = new EmbedBuilder()
        .setColor("#8806CE")
        .setDescription(`He is not gay like u`);

      return message.reply({ embeds: [owner] });
    } else if (User) {
      const gaydalle = new EmbedBuilder()
       .setColor("#8806CE")
        .setDescription(
          `**${User} is ${gayrate}% gay! <:orchuu_cutie:1217905176107815063>**`,
        )
        .setImage(rainbowImg); // ⭐ added

      return message.channel.send({ embeds: [gaydalle] });
    }
  },
};
