const {
  EmbedBuilder,
} = require("discord.js");

module.exports = {
  name: "meme",
  category: "Fun",
  aliases: ["memes"],
  cooldown: 3,
  description: "Send A Meme!",
  args: false,
  usage: "meme",
  userPerms: [],
  owner: false,

  execute: async (message) => {
    try {
      const res = await fetch("https://meme-api.com/gimme");

      if (!res.ok) {
        return message.channel.send("❌ Failed to fetch meme.");
      }

      const data = await res.json();

      const embed = new EmbedBuilder()
        .setColor("#8806CE")
        .setTitle(data.title)
        .setURL(data.postLink)
        .setImage(data.url)
        .setTimestamp();

      return message.channel.send({ embeds: [embed] });

    } catch (error) {
      console.error(error);
      return message.channel.send("⚠️ Meme API error. Try again later.");
    }
  },
};
