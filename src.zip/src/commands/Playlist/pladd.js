const { EmbedBuilder } = require("discord.js");
const db = require("../../schema/playlist");

module.exports = {
  name: "pladd",
  aliases: ["addtopl", "pladdtrack"],
  category: "Playlist",
  cooldown: 3,
  description: "Add a track to your saved playlist.",
  args: true,
  usage: "<playlist name> <song name / url>",
  userPerms: [],
  botPerms: ["EmbedLinks"],
  owner: false,
  player: false,
  inVoiceChannel: false,
  sameVoiceChannel: false,

  execute: async (message, args, client, prefix) => {
    const playlistName = args[0];
    const query = args.slice(1).join(" ");

    if (!query)
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("#8806CE")
            .setDescription(
              `Please provide a song name or URL.\n**Usage:** \`${prefix}pladd <playlist> <song>\``,
            ),
        ],
      });

    // Fetch playlist
    const data = await db.findOne({
      UserId: message.author.id,
      PlaylistName: playlistName,
    });

    if (!data) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("#8806CE")
            .setDescription(
              `Playlist **${playlistName}** not found.\nUse \`${prefix}plcreate <name>\` to make one.`,
            ),
        ],
      });
    }

    // Search track
    const res = await client.manager.search(query, {
      requester: message.author,
    });

    if (!res.tracks || res.tracks.length === 0) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("#8806CE")
            .setDescription(`No results found for **${query}**.`),
        ],
      });
    }

    const track = res.tracks[0];

    // Add to playlist DB
    data.Playlist.push({
      title: track.title,
      uri: track.uri,
      duration: track.duration,
    });

    await data.save();

    return message.reply({
      embeds: [
        new EmbedBuilder()
          .setColor("#8806CE")
          .setDescription(
            `${client.emoji.tick} | Added **[${track.title}](${track.uri})** to playlist **${playlistName}**.`,
          ),
      ],
    });
  },
};
