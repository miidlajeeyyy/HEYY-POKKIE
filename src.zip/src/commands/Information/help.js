const {
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");

module.exports = {
  name: "help",
  category: "Information",
  aliases: ["h"],
  description: "Help with all commands, or one specific command.",
  botParams: ["EmbedLinks", "SendMassges"],
  cooldown: 3,
  execute: async (message, args, client, prefix) => {
    const HELP_BANNER = client.config?.links?.BG || client.config?.links?.arrkiii || "";

    // Main help embed
    const embed = new client.embed()
      .d(
        `- Prefix For This Server: \`${prefix}\`\n- Total Commands: \`${client.slashCommands.size + client.commands.size}\`\n- Prefix Commands: ${client.commands.size}, Slash Commands: ${client.slashCommands.size}`,
      )
      .addFields(
        {
          name: "**__Main Features__**",
          value: `
>  **Antinuke**
>  **Automod**
>  **Config**
>  **Fun**
>  **Information**
>  **Moderation**
>  **Music**
>  **Profile**
>  **Utility**
>  **Voice**
          `,
          inline: true,
        },
        {
          name: "**__Extra Features__**",
          value: `
> **Extra**
>  **Pfps**
>  **Playlists**
>  **Role**
>  **Ticket** 
>  **Verify** 
>  **Generate** 
          `,
          inline: true,
        }
      )
      .setColor("#FD34AC")
      .img(HELP_BANNER)
      .thumb(HELP_BANNER)
      .setFooter({
        text: "Pookie<3•",
        iconURL: HELP_BANNER,
      });

    // Home button
    const button = new ActionRowBuilder().addComponents(
      new client.button().s(`home`, ``, client.emoji.home),
    );

    // Command categories for dropdown menus
    const commandCategories = [
      { label: "Antinuke", value: "antinuke", description: "Get all Antinuke commands", emoji: client.emoji.antinuke },
      { label: "Automod", value: "automod", description: "Get all Automod commands", emoji: "<:meko:1389892185754959912>" },
      { label: "Config", value: "config", description: "Get all Config commands", emoji: client.emoji.config },
      { label: "Extra", value: "extra", description: "Get all Extra commands", emoji: client.emoji.extra },
      { label: "Fun", value: "fun", description: "Get all Fun commands", emoji: client.emoji.fun },
      { label: "Information", value: "information", description: "Get all Information commands", emoji: client.emoji.information },
      { label: "Moderation", value: "moderation", description: "Get all Moderation commands", emoji: client.emoji.moderation },
      { label: "Music", value: "music", description: "Get all Music commands", emoji: client.emoji.music },
      { label: "Pfp", value: "pfp", description: "Get all Pfps commands", emoji: client.emoji.pfp },
      { label: "Playlist", value: "playlist", description: "Get all Playlist commands", emoji: client.emoji.playlist },
      { label: "Profile", value: "profile", description: "Get all Profile commands", emoji: client.emoji.profile },
      { label: "Role", value: "role", description: "Get all Role commands", emoji: client.emoji.role },
      { label: "Utility", value: "utility", description: "Get all Utility commands", emoji: client.emoji.utility },
      { label: "Voice", value: "voice", description: "Get all Voice commands", emoji: client.emoji.voice },
      { label: "Ticket", value: "ticket", description: "Get all Ticket commands", emoji: client.emoji.ticket },
      { label: "Verify", value: "verify", description: "Get all Verify commands", emoji: client.emoji.tick },
      { label: "Generate", value: "generate", description: "Get all Generate commands", emoji: client.emoji.plus },
    ];

    // Main menu select
    const mainMenu = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId("help_main")
        .setPlaceholder("Main Commands")
        .addOptions([
          { label: "Antinuke", value: "antinuke", emoji: client.emoji.antinuke },
          { label: "Automod", value: "automod", emoji: "<:meko:1414560812353327124>" },
          { label: "Config", value: "config", emoji: client.emoji.config },
          { label: "Fun", value: "fun", emoji: client.emoji.fun },
          { label: "Information", value: "information", emoji: client.emoji.information },
          { label: "Moderation", value: "moderation", emoji: client.emoji.moderation },
          { label: "Music", value: "music", emoji: client.emoji.music },
          { label: "Utility", value: "utility", emoji: client.emoji.utility },
          { label: "Voice", value: "voice", emoji: client.emoji.voice },
        ])
    );

    // Extra menu select
    const extraMenu = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId("help_extra")
        .setPlaceholder("Extra Commands")
        .addOptions([
          { label: "Extra", value: "extra", emoji: client.emoji.extra },
          { label: "Pfp", value: "pfp", emoji: client.emoji.pfp },
          { label: "Playlist", value: "playlist", emoji: client.emoji.playlist },
          { label: "Profile", value: "profile", emoji: client.emoji.profile },
          { label: "Role", value: "role", emoji: client.emoji.role },
          { label: "Ticket", value: "ticket", emoji: client.emoji.ticket },
          { label: "Verify", value: "verify", emoji: client.emoji.tick },
          { label: "Generate", value: "generate", emoji: client.emoji.plus },
        ])
    );

    // Send main embed with menus
    const sentMessage = await message.channel.send({
      embeds: [embed],
      components: [mainMenu, extraMenu],
    });

    // Collector for interaction
    const collector = sentMessage.createMessageComponentCollector({
      filter: (interaction) => interaction.user.id === message.author.id,
      time: 60000,
    });

    collector.on("collect", async (interaction) => {
      if (interaction.isButton()) {
        if (interaction.customId === "home") {
          return interaction.update({
            embeds: [embed],
            components: [mainMenu, extraMenu],
          });
        }
      } else if (interaction.isStringSelectMenu()) {
        const selectedCategory = interaction.values[0];
        const categoryCommands = client.commands
          .filter((cmd) => cmd.category?.toLowerCase() === selectedCategory)
          .map((cmd) => `\`${cmd.name}\``);

        const categoryEmbed = new client.embed()
          .d(
            `${categoryCommands.join(", ") || "No commands found for this category."}`,
          )
          .t(
            `${selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)} Commands`,
          )
          .setColor("#FD34AC")
          .setFooter({
            text: `Total ${categoryCommands.length} commands • Pookie<3`,
            iconURL: HELP_BANNER,
          })
          .img(HELP_BANNER);

        await interaction.update({
          embeds: [categoryEmbed],
          components: [mainMenu, extraMenu, button],
        });
      }
    });

    collector.on("end", () => {
      sentMessage.edit({ components: [] });
    });
  },
};
