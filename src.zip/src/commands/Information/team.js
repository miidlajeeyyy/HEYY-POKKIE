/** @format
 *
 * Pookie By paku
 * © 2026 Paku Development
 *
 */

const {
  EmbedBuilder,
  MessageFlags,
  ButtonBuilder,
  ActionRowBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ComponentType,
} = require("discord.js");

module.exports = {
  name: "team",
  category: "Information",
  aliases: ["team"],
  description: "See information about this project.",
  args: false,
  usage: "",
  owner: false,
  cooldown: 3,
  execute: async (message, args, client, prefix, interaction) => {
    // Fetching Team Members

    const CYBER = await client.users.fetch(`1275728664256053354`);
    const PAKU = await client.users.fetch(`1130416772168818748`);
    const STERLING = await client.users.fetch(`880514068958572595`);
    const embedt = new EmbedBuilder()
      .setAuthor({
        name: `${client.user.username}\`'s Team`,
        iconURL: client.user.displayAvatarURL({ dynamic: true, size: 2048 }),
      })
      .setDescription(
        `> ***[${message.author.username}](https://discord.com/users/${message.author.id})*** ***Hello!!***,***High-quality music playback.***
Moderation and utility features.****
Fun and extra commands..***`,
      )
      .setImage(client.config.links.BG || client.config.links.arrkiii)
      .setColor("#ce0692")
      .setThumbnail(message.guild.iconURL({ dynamic: true }))
      .setFooter({
        text: client.config.links.power,
        iconURL: message.author.displayAvatarURL({ dynamic: true }),
      });

    const row = new ActionRowBuilder().addComponents([
      new ButtonBuilder()
        .setStyle(ButtonStyle.Secondary)
        .setCustomId("1")
        .setEmoji("1127607405061079061"),
    ]);

    const devsbaby = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId("teamm")
        .setPlaceholder("Select a Team Member")
        .addOptions([

          {
            label: `${CYBER.displayName}`,
            value: `cyber_owner`,
            description: "Info About Dev!",
            emoji: `1414560021399732355`,
          },

          {
            label: `${PAKU.displayName}`,
            value: `paku_dev`,
            description: "Info About Bot Owner & Developer!",
            emoji: `1414560021399732355`,
          },
          {
            label: `${STERLING.displayName}`,
            value: `sterling_dev`,
            description: "Info About Bot Co Owner!",
            emoji: `1414560021399732355`,
          },
        ]),
    );


    // Embed for Cyber
    const cyberembed = new EmbedBuilder()
      .setThumbnail(CYBER.displayAvatarURL())
      .setAuthor({
        name: "Info About Cyber",
        iconURL: message.guild.iconURL({ dynamic: true, size: 2048 }),
      })
      .setFooter({ text: `Thanks For Using Me <3`, iconURL: message.author.displayAvatarURL() })
      .setDescription(`>  **__Bot Owner__**\n> - [@${CYBER.displayName}](https://discord.com/users/${CYBER.id})\n> **ID:** \`-\` ${CYBER.id}\n\`\`\`ㅤ\`\`\`\n>  **__Social Medias ↓__**\n\n Instagram [Click Here](https://www.instagram.com/x.cyberx/)\n> <:config:1414557557971882089> __[Support!](${client.config.links.support})__`)
      .setColor("#ce0692")
      .setTimestamp();

      // Embed for Paku
    const pakuembed = new EmbedBuilder()
      .setThumbnail(PAKU.displayAvatarURL())
      .setAuthor({
        name: "Info About Paku ",
        iconURL: message.guild.iconURL({ dynamic: true, size: 2048 }),
      })
      .setFooter({ text: `Thanks For Using Me <3`, iconURL: message.author.displayAvatarURL() })
      .setDescription(`>  **__Bot Owner__**\n> - [@${PAKU.displayName}](https://discord.com/users/${PAKU.id})\n> **ID:** \`-\` ${PAKU.id}\n\`\`\`ㅤ\`\`\`\n>  **__Social Medias ↓__**\n\n Instagram [Click Here](https://www.instagram.com/miidlajeeyyy?igsh=MWprd3BncmkxYnZqNw==)\n> <:config:1414557557971882089> __[Support!](${client.config.links.support})__`)
      .setColor("#ce06c1")
      .setTimestamp();

    const msg = await message.channel.send({
      embeds: [embedt],
      components: [devsbaby],
    });

    const collector = await msg.createMessageComponentCollector({
      filter: (i) => {
        if (message.author.id === i.user.id) return true;
        else {
          i.reply({
            content: `${client.emoji.cross} | That's not your session run : \`${prefix}team\` to create your own.`,
            ephemeral: true,
          });
        }
      },
      time: 100000,
    });

    collector.on("collect", async (i) => {
      if (i.isStringSelectMenu()) {
        const value = i.values[0];
        
        if (value === "cyber_owner") {
          return i.update({ embeds: [cyberembed], components: [devsbaby, row] });
        }
        if (value === "paku_dev") {
          return i.update({ embeds: [pakuembed ], components: [devsbaby, row] });
        }
      }
      if (i.isButton()) {
        if (i.customId === "1")
          await i.update({ embeds: [embedt], components: [devsbaby] });
      }
    });

    collector.on("end", async () => {
      if (!msg) return;
      msg.edit({
        components: [],
      }).catch(() => {});
    });
  },
};