
const { EmbedBuilder, PermissionsBitField } = require("discord.js");
module.exports = {
  name: "warn",
  category: "Moderation",
  aliases: [],
  cooldown: 3,
  description: "Warn a user",
  args: true,
  usage: "<user> <reason>",
  userPerms: ["ModerateMembers"],
  owner: false,
  execute: async (message, args, client) => {
    if (!message.member.permissions.has(PermissionsBitField.Flags.ModerateMembers))
      return message.reply("You need Moderate Members permission.");

    const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!member) return message.reply("Mention a valid user.");
    const reason = args.slice(1).join(" ") || "No reason provided";

    const dmEmbed = new EmbedBuilder()
      .setColor("#FFA500")
      .setTitle("⚠️ Warning Received")
      .setDescription(`You have been warned in ${message.guild.name}`)
      .addFields(
        { name: "Moderator", value: `${message.author}` },
        { name: "Reason", value: reason }
      );

    try { await member.send({ embeds:[dmEmbed] }); } catch(e) {}

    const embed = new EmbedBuilder()
      .setColor("#FFA500")
      .setTitle("⚠️ Warning Issued")
      .setDescription(`${member} has been warned`)
      .addFields({ name: "Reason", value: reason });

    return message.reply({ embeds:[embed] });
  }
};
