const {
  ChannelType,
  PermissionsBitField,
} = require("discord.js");

module.exports = {
  name: "generator",
    category: "Generate",
  async execute(message) {

    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator))
      return message.reply("❌ Admin only command");

    const guild = message.guild;

    // prevent duplicate setup
    const exists = guild.channels.cache.find(
      c => c.type === ChannelType.GuildCategory && c.name === "୨🔒୧・𝑱𝑶𝑰𝑵 𝟐 𝑪𝑹𝑬𝑨𝑻𝑬 (𝑷𝑹𝑽𝑻 𝑽𝑪)"
    );
    if (exists) return message.reply("⚠️ Pookie Generator already exists");

    const category = await guild.channels.create({
      name: "୨🔒୧・𝑱𝑶𝑰𝑵 𝟐 𝑪𝑹𝑬𝑨𝑻𝑬 (𝑷𝑹𝑽𝑻 𝑽𝑪)",
      type: ChannelType.GuildCategory,
    });

    const generators = [
      "・ 🍸 ・ General ・ ん",
      "・ 🍸 ・ Solo ・ ん",
      "・ 🍸 ・ Duo ・ ん",
      "・ 🍸 ・ Trio ・ ん",
      "・ 🍸 ・ Squad ・ ん",
    ];

    for (const name of generators) {
      await guild.channels.create({
        name,
        type: ChannelType.GuildVoice,
        parent: category.id,
      });
    }

    message.reply("✅ Pookie Generator setup completed");
  },
};
