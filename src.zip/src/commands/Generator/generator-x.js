const {
  ChannelType,
  PermissionsBitField,
} = require("discord.js");

module.exports = {
  name: "generator-x",
  async execute(message) {

    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator))
      return message.reply("❌ Admin only command");

    const guild = message.guild;

    // prevent duplicate setup
    const exists = guild.channels.cache.find(
      c => c.type === ChannelType.GuildCategory && c.name === "Pookie X Generator"
    );
    if (exists) return message.reply("⚠️ Pookie Generator already exists");

    const category = await guild.channels.create({
      name: "Pookie X Generator",
      type: ChannelType.GuildCategory,
    });

    const generators = [
      "🔸├🏮solo",
      "🔸├🏮duo",
      "🔸├🏮trio",
      "🔸├🏮squad",
      "🔸└🏮Quintet",
    ];

    for (const name of generators) {
      await guild.channels.create({
        name,
        type: ChannelType.GuildVoice,
        parent: category.id,
      });
    }

    message.reply("✅ Pookie Generator setup completed");
  },
};
