/** @format
 *
 * Pookie By Paku
 * © 2026 Paku Development
 *
 */
const {
  EmbedBuilder,
  PermissionsBitField,
  ActionRowBuilder,
  ButtonStyle,
  ButtonBuilder,
  WebhookClient,
  version,
} = require("discord.js");
const db = require("../../schema/prefix.js");
const bl = require("../../schema/blacklist");
const IgnoreChannelModel = require("../../schema/ignorechannel");
const VoteBypassUserModel = require("../../schema/votebypassuser");
const db4 = require("../../schema/noprefix");
const cooldowns = new Map();

module.exports = {
  name: "messageCreate",
  run: async (client, message) => {
    if (message.author.bot) return;
      
      // ===================== COUNTING SYSTEM =====================
const CountingDB = require("../../schema/counting");

// 🎯 Milestones
const MILESTONES = [10, 50, 100, 500, 1000];

try {
  const countingData = await CountingDB.findOne({
    Guild: message.guild.id,
  });

  // If counting is not setup → skip
  if (
    countingData &&
    message.channel.id === countingData.Channel
  ) {
    // Ignore bots ONLY (already handled above)
    const number = parseInt(message.content);
    if (isNaN(number)) return;

    const next = countingData.Count + 1;

    // 🔁 DOUBLE COUNT CHECK
    // 🔁 DOUBLE COUNT CHECK
if (countingData.DoubleCount && countingData.LastUser === message.author.id) {
      await message.react("❌").catch(() => {});

      if (countingData.DoubleCount) {
        countingData.Count = 0;
        countingData.LastUser = null;
        await countingData.save();

        await message.channel.send(
          "❌ **Double count detected!** Count has been reset to **1**."
        );
      }
      return;
    }

    // ❌ WRONG NUMBER CHECK
    if (number !== next) {
      await message.react("❌").catch(() => {});

      if (countingData.FailReset) {
        countingData.Count = 0;
        countingData.LastUser = null;
        await countingData.save();

        await message.channel.send(
          "❌ **Wrong number!** Count has been reset to **1**."
        );
      }
      return;
    }

    // ✅ CORRECT NUMBER
    countingData.Count = number;
    countingData.LastUser = message.author.id;
    await countingData.save();

    await message.react("✅").catch(() => {});

    // 🏆 MILESTONE CHECK
    if (MILESTONES.includes(number)) {
      await message.channel.send(
        `🎉 **MILESTONE REACHED!** 🎉\nThe count reached **${number}** 🚀`
      );
    }

    return; // ⛔ STOP command processing for counting messages
  }
} catch (err) {
  console.error("Counting Error:", err);
}
// =================== END COUNTING SYSTEM ===================


    let prefix = client.prefix;
    const ress = await db.findOne({ Guild: message.guildId });
    if (ress && ress.Prefix) prefix = ress.Prefix;
    const reacter = new RegExp(`^<@!?${client.owner}>( |)$`);

    if (message.content.includes("1130416772168818748")) {
      await message.react("<a:POOKIE:1505097495980544021>").catch(() => {});
    }
      
      if (message.content.includes("1224711618638774286")) {
      await message.react("<:ActiveDeveloperBadge:1342896754915409925>").catch(() => {});
    }
      
        if (message.content.includes("1155753316765151304")) {
      await message.react("<a:fh_blue_butterfly:1414558152246165584>").catch(() => {});
    }    
      
       if (message.content.includes("1449031615723606077")) {
      await message.react("<a:66721butterflypurple:1443157330223956040>").catch(() => {});
    }      
      
       if (message.content.includes("1092320412932767785")) {
      await message.react("<a:fh_blue_butterfly:1414558152246165584>").catch(() => {});
    }      
      
       if (message.content.includes("631398154364911634")) {
      await message.react("<a:fh_blue_butterfly:1414558152246165584>").catch(() => {});
    }      

    const mention = new RegExp(`^<@!?${client.user.id}>( |)$`);
    if (message.content.match(mention)) {
      if (
        !message.guild.members.me.permissions.has(
          PermissionsBitField.resolve("SendMessages"),
        )
      )
        return await message.author
          .send({
            content: `I don't have **\`SEND_MESSAGES\`** permission in <#${message.channelId}> to execute this **\`${command.name}\`** command.`,
          })
          .catch(() => null);

      if (
        !message.guild.members.me.permissions.has(
          PermissionsBitField.resolve("ViewChannel"),
        )
      )
        return;

      if (
        !message.guild.members.me.permissions.has(
          PermissionsBitField.resolve("EmbedLinks"),
        )
      )
        return await message.channel
          .send({
            content: `I don't have **\`EMBED_LINKS\`** permission in <#${message.channelId}> to execute this **\`${command.name}\`** command.`,
          })
          .catch(() => {});
      const embed = new EmbedBuilder()
        .setColor("#8806CE")
        .setDescription(
          `> <:Heartt:1514773205410250925> **Hey ${message.author}**,\n> <a:blackdot:1514711393004421170> **Prefix For This Server\`${prefix}\`**\n\n- ___Type ${prefix}help for more information.___`,
        )
        .setThumbnail(message.author.displayAvatarURL())
        .setImage(client.config.links.arrkiii)
        .setFooter({
          text: `Love From Pookie <3`,
          iconURL: client.user.displayAvatarURL(),
        });

      const button1 = new ActionRowBuilder().addComponents([
        new ButtonBuilder()
          .setStyle(ButtonStyle.Secondary)
          .setCustomId("sys")
          .setLabel("System")
          .setDisabled(true),
        new ButtonBuilder()
          .setStyle(ButtonStyle.Secondary)
          .setCustomId("abtt")
          .setLabel("About Devs")
          .setDisabled(false),
        new ButtonBuilder()
          .setStyle(ButtonStyle.Secondary)
          .setCustomId("linkss")
          .setLabel("Links")
          .setDisabled(false),
        new ButtonBuilder()
          .setStyle(ButtonStyle.Secondary)
          .setCustomId("homm")
          .setEmoji("1127607405061079061")
          .setDisabled(false),
      ]);
      const button2 = new ActionRowBuilder().addComponents([
        new ButtonBuilder()
          .setStyle(ButtonStyle.Secondary)
          .setCustomId("sys")
          .setLabel("System")
          .setDisabled(false),
        new ButtonBuilder()
          .setStyle(ButtonStyle.Secondary)
          .setCustomId("abtt")
          .setLabel("About Devs")
          .setDisabled(true),
        new ButtonBuilder()
          .setStyle(ButtonStyle.Secondary)
          .setCustomId("linkss")
          .setLabel("Links")
          .setDisabled(false),
        new ButtonBuilder()
          .setStyle(ButtonStyle.Secondary)
          .setCustomId("homm")
          .setEmoji("1127607405061079061")
          .setDisabled(false),
      ]);
      const button3 = new ActionRowBuilder().addComponents([
        new ButtonBuilder()
          .setStyle(ButtonStyle.Secondary)
          .setCustomId("sys")
          .setLabel("System")
          .setDisabled(false),
        new ButtonBuilder()
          .setStyle(ButtonStyle.Secondary)
          .setCustomId("abtt")
          .setLabel("About Devs")
          .setDisabled(false),
        new ButtonBuilder()
          .setStyle(ButtonStyle.Secondary)
          .setCustomId("linkss")
          .setLabel("Links")
          .setDisabled(true),
        new ButtonBuilder()
          .setStyle(ButtonStyle.Secondary)
          .setCustomId("homm")
          .setEmoji("1127607405061079061")
          .setDisabled(false),
      ]);
      const button4 = new ActionRowBuilder().addComponents([
        new ButtonBuilder()
          .setStyle(ButtonStyle.Secondary)
          .setCustomId("sys")
          .setLabel("System")
          .setDisabled(false),
        new ButtonBuilder()
          .setStyle(ButtonStyle.Secondary)
          .setCustomId("abtt")
          .setLabel("About Devs")
          .setDisabled(false),
        new ButtonBuilder()
          .setStyle(ButtonStyle.Secondary)
          .setCustomId("linkss")
          .setLabel("Links")
          .setDisabled(false),
        new ButtonBuilder()
          .setStyle(ButtonStyle.Secondary)
          .setCustomId("homm")
          .setEmoji("1127607405061079061")
          .setDisabled(true),
      ]);
      const mssg = await message.channel.send({
        embeds: [embed],
        components: [button4],
      }).catch(() => null);
      const collector = await mssg.createMessageComponentCollector({
        filter: (i) => {
          if (message.author.id === i.user.id) return true;
          else {
            i.reply({
              content: `${client.emoji.cross} | That's not your session run : \`Tag Me\` to create your own.`,
              ephemeral: true,
            });
          }
        },
      });
      const Result = Math.floor(Math.random() * 30);
      const guildsCounts = await client.guilds.cache;
      const channelsCounts = await client.channels.cache;
      const usercount = client.guilds.cache.reduce(
        (acc, guild) => acc + guild.memberCount,
        0,
      );
      const lund = Math.round((Date.now() - message.client.uptime) / 1000);
      const ping = Result;
      const meko1 = new EmbedBuilder()
        .setColor("#8806CE")
        .setFooter({
          text: client.config.links.power,
          iconURL: message.author.displayAvatarURL({ dynamic: true }),
        })
        .setDescription(
          `<:arroww:1414557377918664706> **System Information\n> . Bot Name : ${client.user.username}\n> . Servers : ${client.numb(guildsCounts.size)}\n> . Channels : ${client.numb(channelsCounts.size)}\n> . Users : ${client.numb(usercount)}\n> . Discord.js : ${version}\n> . Total Commands : ${client.numb(client.commands.size)}\n> . Uptime :<t:${lund}:R>\n> . Ping : ${client.ws.ping}ms**`,
        );
      const sterling = await client.users.fetch(`880514068958572595`);
      const paku = await client.users.fetch(`1130416772168818748`);
      const parthipan = await client.users.fetch(`1309593644478500965`);
      const dot = client.emoji. dot;
      const meko2 = new EmbedBuilder()
        .setColor("#8806CE")
        .setImage(client.config.links.arrkiii)
        .setAuthor({
          name: `| Team`,
          iconURL:
            "https://cdn.discordapp.com/emojis/1215695204439293962.webp?size=40&quality=lossless",
          url: client.config.links.support,
        })
        .setDescription(
 `> **\`.01\` ${dot} Bot Owner | [${paku.displayName}](https://discord.com/users/${paku.id})**\n` +
`> **\`.02\` ${dot} Main Developer | [${sterling.displayName}](https://discord.com/users/${sterling.id})**\n` +
`> **\`.03\` ${dot} Co-Developer | [${parthipan.displayName}](https://discord.com/users/${parthipan.id})**`,
        );

      const meko3 = new EmbedBuilder()
        .setColor("#8806CE")
        .setTitle(`**__Links__**`)
        .setImage(client.config.links.arrkiii)
        .setDescription(
          `>>> ***<a:vintageheart:1514766414005797025> Invite Links: [Click Me](${client.config.links.invite})\n Support Server Link [Click Me](${client.config.links.support})\n<:FlowersForYou:1505242170427441273> Privacy Policy Link: [Click Me](https://github.com/z4ck-ftw/moon-privacy-policy/)***`,
        );

      collector.on("collect", async (i) => {
        if (i.customId === "sys") {
          await i.update({ embeds: [meko1], components: [button1] }).catch(() => null);
        } else if (i.customId === "abtt") {
          await i.update({ embeds: [meko2], components: [button2] }).catch(() => null);
        } else if (i.customId === "linkss") {
          await i.update({ embeds: [meko3], components: [button3] }).catch(() => null);
        } else if (i.customId === "homm") {
          await i.update({ embeds: [embed], components: [button4] }).catch(() => null);
        }
      });
    }

    const np = [];
    const npData = await db4.findOne({
      userId: message.author.id,
      noprefix: true,
    });
    if (npData) np.push(message.author.id);

    const regex = new RegExp(`^<@!?${client.user.id}>`);
    const pre = message.content.match(regex)
      ? message.content.match(regex)[0]
      : prefix;
    if (!np.includes(message.author.id)) {
      if (!message.content.startsWith(pre)) return;
    }

    const args =
      np.includes(message.author.id) === false
        ? message.content.slice(pre.length).trim().split(/ +/)
        : message.content.startsWith(pre) === true
          ? message.content.slice(pre.length).trim().split(/ +/)
          : message.content.trim().split(/ +/);
    const commandName = args.shift().toLowerCase();

    const command =
      client.commands.get(commandName) ||
      client.commands.find(
        (cmd) => cmd.aliases && cmd.aliases.includes(commandName),
      );

    if (!command) return;
      
          const blusers = await bl.findOne({userId: message.author.id })
    if (blusers) {
      const embed = new client.embed().a(`You have been blacklisted from using the bot!`, message.author.displayAvatarURL());
      const m = await message.channel.send({ embeds: [embed] }).catch(() => null);
      setTimeout(() => m.delete().catch(() => null), 5000);
      return;
    }

    if (!cooldowns.has(command.name)) {
      cooldowns.set(command.name, new Map());
    }

    const now = Date.now();
    const timestamps = cooldowns.get(command.name);
    const cooldownAmount = (command.cooldown || 3) * 1000; // Default cooldown: 3 seconds

    if (timestamps.has(message.author.id)) {
      const expirationTime = timestamps.get(message.author.id) + cooldownAmount;

      if (now < expirationTime) {
        const timeLeft = Math.round(expirationTime / 1_000);
        const cooldownEmbed = new EmbedBuilder()
          .setColor("#8806CE")
          .setDescription(
            `Please wait **<t:${timeLeft}:R>** before reusing the \`${command.name}\` command.`,
          );
        return message.reply({ embeds: [cooldownEmbed] }).then((msg) => {
          const delayTime = expirationTime - now; // Calculate the remaining cooldown time
          setTimeout(() => {
            msg.delete();
          }, delayTime);
        });
      }
    }
    timestamps.set(message.author.id, now);
    setTimeout(() => timestamps.delete(message.author.id), cooldownAmount);

    const ICHchannelId = message.channel.id;
    const isIgnored = await IgnoreChannelModel.findOne({
      guildId: message.guild.id,
      channelId: ICHchannelId,
    });
    if (isIgnored) {
      const baap = new EmbedBuilder()
        .setAuthor({
          name: `This channel is set to ignored channel..`,
          iconURL: message.author.displayAvatarURL(),
        })
        .setColor("#8806CE");
      const ignoreMessage = await message.channel.send({ embeds: [baap] }).catch(() => null);
      setTimeout(() => {
        ignoreMessage.delete().catch(console.error);
      }, 3000);
      return;
    }

    if (command.voteonly) {
      const hasVoted = await client.topgg.hasVoted(message.author.id);
      const voteBypassUser = await VoteBypassUserModel.findOne({
        userId: message.author.id,
      });
      if (!hasVoted && !voteBypassUser) {
        const embed = new EmbedBuilder()
          .setDescription(
            `__This Command Is Only For Our Voters So Vote Us Now By [Clicking Here](https://top.gg/bot/${client.user.id}/vote)__`,
          )
          .setColor("#8806CE");
        return message.channel.send({ embeds: [embed] }).catch(() => null);
      }
    }

    if (
      !message.guild.members.me.permissions.has(
        PermissionsBitField.resolve("SendMessages"),
      )
    )
      return await message.author
        .send({
          content: `I don't have **\`SEND_MESSAGES\`** permission in <${message.guild.name}> to execute this **\`${command.name}\`** command.`,
        })
        .catch(() => {});

    if (
      !message.guild.members.me.permissions.has(
        PermissionsBitField.resolve("ViewChannel"),
      )
    )
      return;

    if (
      !message.guild.members.me.permissions.has(
        PermissionsBitField.resolve("EmbedLinks"),
      )
    )
      return await message.author
        .send({
          content: `I don't have **\`EMBED_LINKS\`** permission in <#${message.guild.name}> to execute this **\`${command.name}\`** command.`,
        })
        .catch(() => {});

    if (command.args && !args.length) {
      let reply = `You didn't provide any arguments, ${message.author}!`;

      if (command.usage) {
        reply += `\nUsage: \`${prefix}${command.name} ${command.usage}\``;
      }

      const embed = new EmbedBuilder()
        .setColor("#8806CE")
        .setDescription(reply);
      return message.channel.send({ embeds: [embed] }).catch(() => null);
    }

    if (command.botPerms) {
      if (
        !message.guild.members.me.permissions.has(
          PermissionsBitField.resolve(command.botPerms || []),
        )
      ) {
        const embed = new EmbedBuilder().setDescription(
          `I don't have **\`${command.botPerms}\`** permission in <#${message.channelId}> to execute this **\`${command.name}\`** command.`,
        );
        return message.channel.send({ embeds: [embed] }).catch(() => null);
      }
    }
    if (command.userPerms) {
      if (
        !message.member.permissions.has(
          PermissionsBitField.resolve(command.userPerms || []),
        )
      ) {
        const embed = new EmbedBuilder()
          .setColor("#8806CE")
          .setDescription(
            `You don't have **\`${command.userPerms}\`** permission in <#${message.channelId}> to execute this **\`${command.name}\`** command.`,
          );
        return message.channel.send({ embeds: [embed] }).catch(() => null);
      }
    }

    if (command.owner && message.author.id !== `${client.owner}`) {
      const paku = await client.users.fetch(`1130416772168818748`);
      const embed = new EmbedBuilder().setColor("#8806CE").setAuthor({
        name: `| Only ${paku.displayName} can use this cmds!`,
        iconURL: message.author.displayAvatarURL(),
      });
      return message.channel.send({ embeds: [embed] }).catch(() => null);
    }

    const player = client.manager.players.get(message.guild.id);
    if (command.player && !player) {
      return message.channel.send(`i'm not in any vc!`).catch(() => null);;
    }
    if (command.inVoiceChannel && !message.member.voice.channelId) {
      const embed = new EmbedBuilder().setColor("#8806CE").setAuthor({
        name: `Your are not in any vc`,
        iconURL: message.author.displayAvatarURL(),
        url: client.config.links.support,
      });
      return message.channel.send({ embeds: [embed] }).catch(() => null);
    }

    if (command.sameVoiceChannel) {
      if (message.guild.members.me.voice.channel) {
        if (
          message.guild.members.me.voice.channelId !==
          message.member.voice.channelId
        ) {
          const embed = new EmbedBuilder().setColor("#8806CE").setAuthor({
            name: `Your are not in same vc`,
            iconURL: message.author.displayAvatarURL(),
            url: client.config.links.support,
          });
          return message.channel.send({ embeds: [embed] }).catch(() => null);
        }
      }
    }
    //

    command.execute(message, args, client, prefix).catch((e) => {
      console.log(e);
    });
    if (command && command.execute) {
      const log = client.channels.cache.get(`1241614535568134236`);
      const web = new WebhookClient({
        url: client.config.Webhooks.cmdrun,
      });
      const commandlog = new EmbedBuilder()
        .setAuthor({
          name: message.author.tag,
          iconURL: message.author.displayAvatarURL({ dynamic: true }),
        })
        .setColor("#8806CE")
        .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
        .setTimestamp()
        .setDescription(
          `Command Just Used In : \`${message.guild.name} | ${message.guild.id}\`\n Command Used In Channel : \`${message.channel.name} | ${message.channel.id}\`\n Command Name : \`${command.name}\`\n Command Executor : \`${message.author.tag} | ${message.author.id}\`\n Command Content : \`${message.content}\``,
        );
      web.send({ embeds: [commandlog] });
    }
  },
};
