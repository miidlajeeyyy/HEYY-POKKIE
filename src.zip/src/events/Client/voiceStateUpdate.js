const { ChannelType } = require("discord.js");
const PookieVC = require("../../schema/MoonVC");
const vcConfig = require("../../config/voiceGenerator");

/**
 * CATEGORY-SPECIFIC LIMITS
 */
const generators = vcConfig.generators;

/**
 * Helper to get next available VC name
 */
function getNextVCName(baseName, category, guild) {
  const existingNumbers = guild.channels.cache
    .filter(
      c =>
        c.type === ChannelType.GuildVoice &&
        c.parentId === category.id &&
        c.name.startsWith(baseName)
    )
    .map(c => {
      const match = c.name.match(/-(\d+)$/);
      return match ? parseInt(match[1]) : 0;
    });

  let nextNumber = 1;
  while (existingNumbers.includes(nextNumber)) nextNumber++;

  return `${baseName}-${nextNumber}`;
}


module.exports = {
  name: "voiceStateUpdate",
  async run(client, oldState, newState) {
    // Only when joining
    if (!newState.channelId) return;

    const channel = newState.channel;
    const member = newState.member;
    const guild = newState.guild;

    if (!channel?.parent) return;

    // Get category config
    const categoryLimits = generators[channel.parent.name];
    if (!categoryLimits) return;

    // Check if channel is a trigger
    if (!categoryLimits[channel.name]) return;

    const limit = categoryLimits[channel.name];
    const baseName = channel.name;

    // Normalize type for DB (solo/duo/etc)
    const type = channel.name.replace(/[^a-zA-Z]/g, "").toLowerCase();

    const dbVCs = await PookieVC.find({
      guildId: guild.id,
      type,
      categoryId: channel.parent.id,
    });

    // Find available VC
    let targetVC = dbVCs
      .map(d => guild.channels.cache.get(d.channelId))
      .find(vc => vc && vc.members.size < limit);

    // Create VC if none exists
    if (!targetVC) {
      const vcName = getNextVCName(baseName, channel.parent, guild);

      targetVC = await guild.channels.create({
        name: vcName,
        type: ChannelType.GuildVoice,
        parent: channel.parent.id,
        userLimit: limit,
      });

      await PookieVC.create({
        guildId: guild.id,
        channelId: targetVC.id,
        type,
        categoryId: channel.parent.id,
      });
    }

    // Delay to prevent race issues
    await new Promise(r => setTimeout(r, 300));
    if (!member.voice.channelId) return;

    // Move member
    await member.voice.setChannel(targetVC);

    // Auto-delete empty VC
    setTimeout(async () => {
      if (targetVC.deleted) return;
      if (targetVC.members.size === 0) {
        await PookieVC.deleteOne({ channelId: targetVC.id });
        await targetVC.delete().catch(() => {});
      }
    }, 10000);
  },
};