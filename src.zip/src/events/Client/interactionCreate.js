const {
  ChannelType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  InteractionType,
  PermissionFlagsBits,
  PermissionsBitField,
  EmbedBuilder,
  MessageFlags,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require("discord.js");
const db = require("../../schema/prefix.js");
const db3 = require("../../schema/setup");
const MoonVC = require("../../schema/MoonVC");
const Verify = require("../../schema/verifySchema");
const captchaMap = new Map();

module.exports = {
  name: "interactionCreate",
  run: async (client, interaction) => {
    let prefix = client.prefix;
    const ress = await db.findOne({ Guild: interaction.guildId });
    if (ress && ress.Prefix) prefix = ress.Prefix;

    if (interaction.type === InteractionType.ApplicationCommand) {
      const command = client.slashCommands.get(interaction.commandName);
      if (!command) return;

      const embed = new EmbedBuilder().setColor(client.color);

      if (command.botPerms) {
        if (
          !interaction.guild.members.me.permissions.has(
            PermissionsBitField.resolve(command.botPerms || []),
          )
        ) {
          embed.setDescription(
            `I don't have **\`${
              command.botPerms
            }\`** permission in ${interaction.channel.toString()} to execute this **\`${
              command.name
            }\`** command.`,
          );
          return interaction.reply({ embeds: [embed] });
        }
      }

      if (command.userPerms) {
        if (
          !interaction.member.permissions.has(
            PermissionsBitField.resolve(command.userPerms || []),
          )
        ) {
          embed.setDescription(
            `You don't have **\`${
              command.userPerms
            }\`** permission in ${interaction.channel.toString()} to execute this **\`${
              command.name
            }\`** command.`,
          );
          return interaction.reply({ embeds: [embed] });
        }
      }

      const player = interaction.client.manager.players.get(
        interaction.guildId,
      );
      if (command.player && !player) {
        if (interaction.replied) {
          return await interaction
            .editReply({
              content: `There is no player for this guild.`,
              flags: MessageFlags.Ephemeral,
            })
            .catch(() => {});
        } else {
          return await interaction
            .reply({
              content: `There is no player for this guild.`,
              flags: MessageFlags.Ephemeral,
            })
            .catch(() => {});
        }
      }
      if (command.inVoiceChannel && !interaction.member.voice.channel) {
        if (interaction.replied) {
          return await interaction
            .editReply({
              content: `You must be in a voice channel!`,
              flags: MessageFlags.Ephemeral,
            })
            .catch(() => {});
        } else {
          return await interaction
            .reply({
              content: `You must be in a voice channel!`,
              flags: MessageFlags.Ephemeral,
            })
            .catch(() => {});
        }
      }
      if (command.sameVoiceChannel) {
        // Ensure the guild and bot's member instance are defined
        if (!interaction.guild || !interaction.guild.members.me) {
          return await interaction
            .reply({
              content: `An error occurred. It seems the bot is not properly connected to the guild.`,
              flags: MessageFlags.Ephemeral,
            })
            .catch(() => {});
        }

        const botVoiceChannel = interaction.guild.members.me.voice.channel;
        const userVoiceChannel = interaction.member.voice.channel;

        // Check if the bot is in a voice channel
        if (botVoiceChannel) {
          // Ensure the user is in the same voice channel as the bot
          if (userVoiceChannel !== botVoiceChannel) {
            return await interaction
              .reply({
                content: `You must be in the same ${botVoiceChannel.toString()} to use this command!`,
                flags: MessageFlags.Ephemeral,
              })
              .catch(() => {});
          }
        }
      }

      try {
        await command.run(client, interaction, prefix);
      } catch (error) {
        if (interaction.replied) {
          await interaction
            .editReply({
              content: `An unexcepted error occured.`,
            })
            .catch(() => {});
        } else {
          await interaction
            .reply({
              flags: MessageFlags.Ephemeral,
              content: `An unexcepted error occured.`,
            })
            .catch(() => {});
        }
        console.error(error);
      }
    }

    if (interaction.isModalSubmit()) {
      try {
          /* =======================
   🔐 VERIFY MODAL
======================= */
if (interaction.isModalSubmit() && interaction.customId === "verify_modal") {
  const config = await Verify.findOne({ guildId: interaction.guildId });
  if (!config)
    return interaction.reply({ content: "❌ Not set up.", ephemeral: true });

  const input = interaction.fields
    .getTextInputValue("captcha_input")
    .toUpperCase();

  const captcha = captchaMap.get(interaction.user.id);
  if (!captcha)
    return interaction.reply({ content: "⏰ CAPTCHA expired.", ephemeral: true });

  if (input !== captcha)
    return interaction.reply({ content: "❌ Wrong CAPTCHA.", ephemeral: true });

  await interaction.member.roles.add(config.roleId);
  captchaMap.delete(interaction.user.id);

  return interaction.reply({ content: "✅ You are verified!", ephemeral: true });
}


        const command = require("../../commands/Profile/bioset"); // Adjust path if necessary
        await command.modalHandler(interaction); // Call the modal handler
      } catch (error) {
        console.error("Error handling modal submission:", error);
        await interaction.reply({
          content:
            "There was an error processing your input. Please try again.",
        });
      }
    }

    if (interaction.isButton()) {
  if (!interaction.guild) return;

        /* =======================
   🔐 VERIFY BUTTON
======================= */
if (interaction.customId === "verify_button") {
  const config = await Verify.findOne({ guildId: interaction.guildId });
  if (!config)
    return interaction.reply({
      content: "❌ Verification system not set up.",
      ephemeral: true,
    });

  // ✅ CHECK IF USER ALREADY VERIFIED
  if (interaction.member.roles.cache.has(config.roleId)) {
    return interaction.reply({
      content: "✅ You are already verified.",
      ephemeral: true,
    });
  }

  const captcha = Math.random()
    .toString(36)
    .substring(2, 8)
    .toUpperCase();

  captchaMap.set(interaction.user.id, captcha);

  const modal = new ModalBuilder()
    .setCustomId("verify_modal")
    .setTitle("🔐 Verification");

  const input = new TextInputBuilder()
    .setCustomId("captcha_input")
    .setLabel(`Enter CAPTCHA: ${captcha}`)
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(input)
  );

  return interaction.showModal(modal);
}
        
  /* =======================
     🎟️ TICKET BUTTONS
  ======================= */

  // CREATE TICKET
const logsCh = interaction.guild.channels.cache.find(
  c => c.name === "ticket-logs" && c.type === ChannelType.GuildText
);

const transcriptsCh = interaction.guild.channels.cache.find(
  c => c.name === "ticket-transcripts" && c.type === ChannelType.GuildText
);


  if (interaction.customId === "create_ticket_btn") {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    const guild = interaction.guild;

    const adminRole = guild.roles.cache.find(r => r.name === "Ticket Admin");
    const managerRole = guild.roles.cache.find(r => r.name === "Ticket Manager");
    const ticketCategory = guild.channels.cache.find(
      c => c.name === "Tickets" && c.type === ChannelType.GuildCategory
    );

    const safeName = `ticket-${interaction.user.username}`
      .toLowerCase()
      .replace(/[^a-z0-9-_]/g, "-")
      .slice(0, 90);

    const channel = await guild.channels.create({
      name: safeName,
      type: ChannelType.GuildText,
      parent: ticketCategory?.id,
      permissionOverwrites: [
        { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
        {
          id: interaction.user.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
          ],
        },
        ...(adminRole
          ? [{ id: adminRole.id, allow: [PermissionFlagsBits.ViewChannel] }]
          : []),
        ...(managerRole
          ? [{ id: managerRole.id, allow: [PermissionFlagsBits.ViewChannel] }]
          : []),
      ],
    });
await channel.setTopic(`owner:${interaction.user.id}`);

    const embed = new EmbedBuilder()
      .setTitle("🎟️ Ticket Created")
      .setDescription(`Hello ${interaction.user}, staff will assist you shortly.`)
      .setColor(client.color);

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("close_ticket_btn")
        .setLabel("Close")
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId("claim_ticket_btn")
        .setLabel("Claim")
        .setStyle(ButtonStyle.Success),
    );

    await channel.send({ embeds: [embed], components: [row] });

    return interaction.editReply({
      content: `✅ Ticket created: ${channel}`,
      flags: MessageFlags.Ephemeral,
    });
  }

  // CLOSE TICKET
if (interaction.customId === "close_ticket_btn") {
  await interaction.reply({
    content: "⏳ Closing ticket & saving transcript...",
    ephemeral: true,
  });

  const channel = interaction.channel;

  // Fetch last 100 messages
  const messages = await channel.messages.fetch({ limit: 100 });
  const transcript = messages
    .reverse()
    .map(
      m =>
        `${m.author.tag} [${new Date(
          m.createdTimestamp
        ).toLocaleString()}]: ${m.content || "[attachment]"}`
    )
    .join("\n") || "No messages";

  const buffer = Buffer.from(transcript, "utf-8");
  const fileName = `transcript-${channel.id}.txt`;

  // Ticket owner
  const ownerId = channel.topic?.split("owner:")[1]?.trim();
let owner = null;
if (ownerId) {
  owner = await interaction.guild.members.fetch(ownerId).catch(err => {
    console.log("Failed to fetch ticket owner:", err);
    return null;
  });
}

  // Transcript channel
  const transcriptsCh = interaction.guild.channels.cache.find(
    c => c.name === "ticket-transcripts" && c.type === ChannelType.GuildText
  );

  // Logs channel
  const logsCh = interaction.guild.channels.cache.find(
    c => c.name === "ticket-logs" && c.type === ChannelType.GuildText
  );

  // Send transcript to channel
  if (transcriptsCh)
    await transcriptsCh.send({
      content: `📁 Transcript for **${channel.name}**`,
      files: [{ attachment: buffer, name: fileName }],
    }).catch(console.error);

  // Send DM to owner
  if (owner) {
  await owner.send({
    content: `📁 Your ticket **${channel.name}** transcript`,
    files: [{ attachment: buffer, name: fileName }],
  }).catch(err => console.log("Failed to send DM:", err));
}

  // Send log
  if (logsCh)
    await logsCh.send({
      embeds: [
        new EmbedBuilder()
          .setTitle("❌ Ticket Closed")
          .setDescription(`Ticket: ${channel.name}\nClosed by: ${interaction.user.tag}`)
          .setColor("#8806ce")
          .setTimestamp(),
      ],
    }).catch(console.error);

  // Delete the ticket channel
  await channel.delete().catch(() => {});
}

  // CLAIM TICKET
  if (interaction.customId === "claim_ticket_btn") {
    const adminRole = interaction.guild.roles.cache.find(
      r => r.name === "Ticket Admin"
    );
    const managerRole = interaction.guild.roles.cache.find(
      r => r.name === "Ticket Manager"
    );

    const isAdmin = adminRole
      ? interaction.member.roles.cache.has(adminRole.id)
      : false;

    const isManager = managerRole
      ? interaction.member.roles.cache.has(managerRole.id)
      : false;

    if (!isAdmin && !isManager) {
      return interaction.reply({
        content: "❌ Only ticket staff can claim tickets.",
        flags: MessageFlags.Ephemeral,
      });
    }

    if (interaction.replied || interaction.deferred) {
      return interaction.editReply({
        content: `✅ ${interaction.user.tag} claimed this ticket.`,
        flags: MessageFlags.Ephemeral,
      }).catch(() => {});
    }

    return interaction.reply({
      content: `✅ ${interaction.user.tag} claimed this ticket.`,
      flags: MessageFlags.Ephemeral,
    });
  }

   /* =======================
     🎵 MUSIC BUTTONS
  ======================= */

  const data = await db3.findOne({ Guild: interaction.guildId });
  if (
    data &&
    interaction.channelId === data.Channel &&
    interaction.message.id === data.Message
  ) {
    return client.emit("playerButtons", interaction, data);
  }
} // end interaction.isButton
} // end run
}; // end module.exports
