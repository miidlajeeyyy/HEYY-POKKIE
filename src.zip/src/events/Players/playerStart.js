const {
  EmbedBuilder,
  WebhookClient,
  AttachmentBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ComponentType,
} = require("discord.js");
const moment = require("moment");
require("moment-duration-format");

const Presets = require("../../schema/preset");
const VcStatus = require("../../schema/vcstatus");
const { musicCard } = require("musicard-quartz");
const { Classic } = require("musicard");
const canvafy = require("canvafy");

const {
  Webhooks: { player_create },
} = require("../../config.js");

// Helper: Button row
const createButtonRow = (paused, client) => {

const row1 = new ActionRowBuilder().addComponents(
new client.button().s("previous", "", "<:backward:1515491608919933080>"),

new client.button().s(
paused ? "resume" : "pause",
"",
paused ? "<:resume:1515492125071114433>" : "<:Pause:1515492499722866922>"
),

new client.button().s("skip", "", "<:forward:1515492780300828703> "),
new client.button().s("stop", "", "<:stop1:1515493047045984336>"),
new client.button().s("loop", "", "<:loop:1515493257402908782>")
);

const row2 = new ActionRowBuilder().addComponents(
new client.button().s("shuffle", "", "<:shuffle:1515493619534925974>"),
new client.button().s("vol_down", "", "<:volDown:1515493890222723153>"),
new client.button().s("vol_up", "", "<:volUp:1515494293148532778>"),
new client.button().s("vol_max", "", "<:volume:1515494527152947363>"),
new client.button().s("fav", "", "<:favourite:1515495439061749931>")
);

return [row1, row2];
};

// Helper for persistent Filter Menu
const createFilterRow = () => {
  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId("disable_h")
      .setPlaceholder("Select Filters")
      .addOptions([
        { label: "Reset Filters", value: "clearbut" },
        { label: "BassBoost", value: "bassbut" },
        { label: "8D", value: "8dbut" },
        { label: "NightCore", value: "nightbut" },
        { label: "Pitch", value: "pitchbut" },
        { label: "Lofi", value: "lofibut" },
        { label: "Distort", value: "distortbut" },
        { label: "Speed", value: "speedbut" },
        { label: "Vaporwave", value: "vapobut" },
      ])
  );
};

// Helper: Send Now Playing message
async function sendNowPlaying(client, player, track, presetType) {
  const channel = client.channels.cache.get(player.textId);
  if (!channel) return;

  const song = player.queue.current;
  const songUrl = song.uri || client.config.links.support;
  const gud = song.title.replace(/(?:hd|full|video|official|4k|8k)/gi, "");
  const title = gud.replace(/[^\p{L}\p{N}\s\u0900-\u097F]/gu, "").replace(/\s+/g, " ").trim();
  const auth = song.author;
  const total = song.length;
  const thumb = song.thumbnail.replace("hqdefault", "maxresdefault");
  const rows = createButtonRow(false, client);
  const eqrow = createFilterRow();

  const mainEmbed = new EmbedBuilder()
    .setColor("#FD34AC")
    .setTitle("<:a_pinkbutterfly:1511676701619257507> Now Playing")
    .setDescription(`[${title}](${songUrl})`)
    .addFields([
      {
        name: "Author",
        value: auth,
        inline: true,
      },
      {
        name: "Duration",
        value: moment.duration(total).format("hh:mm:ss"),
        inline: true,
      },
    ]);

  let attachment;

  switch (presetType) {
    case 1: {
      const card = new musicCard()
        .setName(auth)
        .setAuthor(title)
        .setColor("#FD34AC")
        .setTheme("quartz+")
        .setBrightness(45)
        .setThumbnail(thumb)
        .setProgress(0)
        .setStartTime("0:00")
        .setEndTime(moment.duration(total).format("hh:mm:ss"));
      attachment = new AttachmentBuilder(await card.build(), { name: "music_card.png" });
      
      return channel.send({ files: [attachment], components: [eqrow, ...rows] });
    }

    case 2: {
      const musicard = await Classic({
        thumbnailImage: thumb,
        backgroundColor: "#0B0B0B",
        progress: 0,
        progressColor: "#FD34AC",
        progressBarColor: "#FFD3EA",
        name: title,
        nameColor: "#FFFFFF",
        author: `By ${auth}`,
        authorColor: "#FFD3EA",
        startTime: "0:00",
        endTime: moment.duration(total).format("hh:mm:ss"),
        timeColor: "#FFFFFF",
      });
      attachment = new AttachmentBuilder(musicard, { name: "music_card.png" });
      
      return channel.send({ files: [attachment], components: [eqrow, ...rows] });
    }

    case 3: {
      const spotify = await new canvafy.Spotify()
        .setAuthor(auth)
        .setTimestamp(1000, total)
        .setImage(thumb)
        .setTitle(title)
        .setBlur(1)
        .setOverlayOpacity(0.5)
        .build();
      attachment = new AttachmentBuilder(spotify, { name: "music_card.png" });
      
      return channel.send({ files: [attachment], components: [eqrow, ...rows] });
    }

    case 4: {
      const letn = Math.round((Date.now() + total) / 1000);
      const embed4 = new EmbedBuilder()
        .setAuthor({ name: `${client.user.username} Is Playing`, iconURL: track.requester.displayAvatarURL() })
        .setDescription(
          `${client.emoji.playing} [${title}](${songUrl})\n\n> Ends <t:${letn}:R>\n> Author [${auth}](${client.config.links.support})\n> Requester [${track.requester.displayName}](${client.config.links.support})`
        )
        .setImage(client.config.links.image)
        .setColor(client.color);

      return channel.send({
        embeds: [embed4],
        components: [eqrow, ...rows],
      });
    }

    default: {
      const musicard = await Classic({
        thumbnailImage: thumb,
        backgroundColor: "#0B0B0B",
        progress: 0,
        progressColor: "#FD34AC",
        progressBarColor: "#FFD3EA",
        name: title,
        nameColor: "#FFFFFF",
        author: `By ${auth}`,
        authorColor: "#FFD3EA",
        startTime: "0:00",
        endTime: moment.duration(total).format("hh:mm:ss"),
        timeColor: "#FFFFFF",
      });
      attachment = new AttachmentBuilder(musicard, { name: "music_card.png" });

      return channel.send({ files: [attachment], components: [eqrow, ...rows] });
    }
  }
}

// MAIN HANDLER
module.exports = {
  name: "playerStart",
  run: async (client, player, track) => {
    const guild = client.guilds.cache.get(player.guildId);
    if (!guild) return;

    new WebhookClient({ url: player_create }).send({
      embeds: [
        new EmbedBuilder()
          .setColor(client.color)
          .setAuthor({ name: `Player Started`, iconURL: client.user.displayAvatarURL() })
          .setDescription(`**Server ID:** ${player.guildId}\n**Server Name:** ${guild.name}\n**Req:** ${track.requester}`),
      ],
    });

    const existing = await VcStatus.findOne({ guildId: guild.id });
    const presetDoc = await Presets.findOne({ guildId: guild.id });
    const presetType = presetDoc?.presetType || 0;
    const nplaying = await sendNowPlaying(client, player, track, presetType);
    if (!nplaying) return;

    player.data.set("message", nplaying);

    if (existing) {
      const rawTitle = String(player.queue.current?.title || track?.title || "Now Playing");
      const statusText = rawTitle
        .replace(/\s+/g, " ")
        .replace(/[\u0000-\u001F\u007F]+/g, "")
        .trim()
        .slice(0, 500);

      client.rest
        .put(`/channels/${player.voiceId}/voice-status`, {
          body: { status: `${client.emoji.playing || "🎶"} ${statusText}` },
        })
        .catch(() => null);
    }

    const collector = nplaying.createMessageComponentCollector({
      time: track.duration,
      componentType: ComponentType.MessageComponent,
    });

    collector.on("collect", async (interaction) => {
      if (interaction.member.voice.channelId !== player.voiceId) {
        return interaction.reply({
          content: `${client.emoji.cross} | You must be in the same voice channel.`,
          ephemeral: true,
        });
      }

      if (interaction.isButton()) {
        const eqrow = createFilterRow(); // Re-create filter row for updates

        switch (interaction.customId) {
          case "previous": {
            const previous = player.queue.previous;
            if (!previous || previous.length === 0) {
              const embed = new EmbedBuilder().setColor("#ff0000").setDescription("There is no previous song to play.");
              return interaction.reply({ embeds: [embed], ephemeral: true });
            }
            player.queue.unshift(previous[previous.length - 1]);
            player.skip();
            break;
          }

          case "pause":
            player.pause(true);
            await interaction.update({
              components: [eqrow, ...createButtonRow(true, client)] // Keep filters + update buttons
            });
            break;

          case "resume":
            player.pause(false);
            await interaction.update({
              components: [eqrow, ...createButtonRow(false, client)] // Keep filters + update buttons
            });
            break;

          case "skip":
            player.skip();
            await interaction.reply({ content: `${client.emoji.skip} | Skipped the track.`, ephemeral: true });
            break;

          case "stop":
            player.queue.clear();
            player.playing = false;
            await player.skip();
            await interaction.reply({ content: `${client.emoji.stop} | Stopped playing`, ephemeral: true });
            break;

          case "loop":
            player.setLoop(player.loop === "none" ? "track" : "none");
            await interaction.reply({ content: `Looping: ${player.loop}`, ephemeral: true });
            break;

          case "shuffle":
            player.queue.shuffle();
            await interaction.reply({ content: `Queue shuffled.`, ephemeral: true });
            break;

          case "vol_down":
            player.setVolume(Math.max(0, player.volume - 10));
            await interaction.reply({ content: `Volume decreased to : ${player.volume}%`, ephemeral: true });
            break;

          case "vol_up":
            player.setVolume(Math.min(100, player.volume + 10));
            await interaction.reply({ content: `Volume increased to : ${player.volume}%`, ephemeral: true });
            break;

          case "vol_max":
            player.setVolume(100);
            await interaction.reply({ content: `Volume increased to 100%`, ephemeral: true });
            break;
        }
      } else if (interaction.isStringSelectMenu()) {
        await interaction.deferReply({ ephemeral: true });
        const val = interaction.values[0];
        const filters = {
          clearbut: { op: "filters", guildId: interaction.guild.id },
          bassbut: { op: "filters", guildId: interaction.guild.id, equalizer: Array(14).fill({}).map((_, i) => ({ band: i, gain: i < 2 || i > 11 ? 0.1 : -0.05 })) },
          "8dbut": { op: "filters", guildId: interaction.guild.id, rotation: { rotationHz: 0.2 } },
          nightbut: { op: "filters", guildId: interaction.guild.id, equalizer: [{ band: 1, gain: 0.3 }, { band: 0, gain: 0.3 }], timescale: { pitch: 1.2 }, tremolo: { depth: 0.3, frequency: 14 } },
          pitchbut: { op: "filters", guildId: interaction.guild.id, timescale: { pitch: 1.245, rate: 1.921 } },
          lofibut: { op: "filters", guildId: interaction.guild.id, equalizer: Array(14).fill({}).map((_, i) => ({ band: i, gain: i <= 4 ? -0.25 + i * 0.05 : (i - 5) * 0.05 })) },
          distortbut: { op: "filters", guildId: interaction.guild.id, equalizer: Array(14).fill({}).map((_, i) => ({ band: i, gain: 0.5 - i * 0.05 })) },
          speedbut: { op: "filters", guildId: interaction.guild.id, timescale: { speed: 1.501, pitch: 1.245, rate: 1.921 } },
          vapobut: { op: "filters", guildId: interaction.guild.id, equalizer: [{ band: 1, gain: 0.3 }, { band: 0, gain: 0.3 }], timescale: { pitch: 0.5 }, tremolo: { depth: 0.3, frequency: 14 } },
        };
        if (filters[val]) {
          await player.shoukaku.setFilters(filters[val]);
          await interaction.editReply({ content: `Enabled **${val.replace("but", "")}**.` });
        }
      }
    });
  },
};
