const {
  ActionRowBuilder,
  ButtonBuilder,
  EmbedBuilder,
  MessageFlags,
  ButtonStyle,
} = require("discord.js");
const { KazagumoPlayer } = require("kazagumo");

module.exports = {
  name: "playerCreate",

  /**
   *
   * @param {Client} client
   * @param {KazagumoPlayer} player
   */

  run: async (client, player) => {
    const name = client.guilds.cache.get(player.guildId).name;
    client.logger.log(`Player Create in ${name} [ ${player.guildId} ]`, "log");
    client.rest
      .put(`/channels/${player.voiceId}/voice-status`, {
        body: { status: `**<a:pink:1511675191783198871> use /play to get started <:a_pinkbutterfly:1511676701619257507>**` },
      })
      .catch(() => null);

    const guild = client.guilds.cache.get(player.guildId);
    if (!guild) return;
  },
};
