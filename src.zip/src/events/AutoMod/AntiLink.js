const { PermissionsBitField } = require("discord.js");
const db = require("../../schema/antilink");

module.exports = {
  name: "messageCreate",
  run: async (client, message) => {
    if (!message.guild || message.author.bot) return;

    const antiLinkData = await db.findOne({ guildId: message.guild.id });
    if (!antiLinkData?.isEnabled) return;

    const botMember = message.guild.members.me;
    if (!botMember) return;

    // Whitelist check
    if (
      antiLinkData.whitelistUsers?.includes(message.author.id) ||
      message.member.roles.cache.some(role =>
        antiLinkData.whitelistRoles?.includes(role.id)
      )
    ) return;

    // Role & admin bypass
    if (
      message.member.permissions.has(PermissionsBitField.Flags.Administrator) ||
      message.member.roles.highest.comparePositionTo(botMember.roles.highest) >= 0
    ) return;

    // Permission check
    if (!botMember.permissions.has(PermissionsBitField.Flags.ManageMessages)) return;

    const linkRegex = /(?:https?:\/\/|discord\.gg\/)/gi;
    if (!linkRegex.test(message.content)) return;

    try {
      // Safe delete
      if (message.deletable) {
        await message.delete().catch(() => {});
      }

      // Safe timeout
      if (message.member.moderatable) {
        await message.member.timeout(
          5 * 60 * 1000,
          "Posted a prohibited link"
        ).catch(() => {});
      }

      const notification = await message.channel.send(
        `🚫 **${message.author.username}** muted for **5 minutes** for posting links.`
      ).catch(() => null);

      if (notification) {
        setTimeout(() => {
          notification.delete().catch(() => {});
        }, 5000);
      }

    } catch (err) {
      // Ignore unknown message error completely
      if (err?.code !== 10008) {
        console.error("AntiLink Error:", err);
      }
    }
  },
};
