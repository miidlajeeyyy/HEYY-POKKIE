const {
  EmbedBuilder,
  CommandInteraction,
  Client,
  MessageFlags
} = require("discord.js");

module.exports = {
  name: "autoplay",
  description: "Toggle Autoplay",
  userPrams: [],
  botPrams: ["EMBED_LINKS"],
  player: true,
  inVoiceChannel: true,
  sameVoiceChannel: true,

  /**
   * @param {Client} client
   * @param {CommandInteraction} interaction
   */

  run: async (client, interaction) => {

    await interaction.deferReply({
      flags: MessageFlags.Ephemeral // ✅ FIXED
    });

    const player = client.manager.players.get(interaction.guild.id);

    // ✅ STRONG SAFETY CHECK
    if (!player || player.destroyed) {
      return interaction.editReply({
        content: "❌ No active player found."
      });
    }

    if (!player.queue || !player.queue.current) {
      const embed = new EmbedBuilder()
        .setColor("#8806CE")
        .setDescription("❌ Play a song first!");

      return interaction.editReply({ embeds: [embed] });
    }

    const autoplay = player.data.get("autoplay") || false;
    const song = player.queue.current;

    // ✅ DOUBLE SAFETY (important)
    if (!song || !song.identifier) {
      return interaction.editReply({
        content: "❌ Invalid track data."
      });
    }

    if (autoplay) {

      player.data.set("autoplay", false);

      const embed = new EmbedBuilder()
        .setColor("#8806CE")
        .setDescription("Autoplay is now Disabled");

      return interaction.editReply({ embeds: [embed] });

    } else {

      player.data.set("autoplay", true);
      player.data.set("requester", client.user);
      player.data.set("identifier", song.identifier);

      const embed = new EmbedBuilder()
        .setColor("#8806CE")
        .setDescription("Autoplay is now Enabled");

      return interaction.editReply({ embeds: [embed] });
    }
  },
};