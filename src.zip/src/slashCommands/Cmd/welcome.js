/** @format */

const {
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    StringSelectMenuBuilder,
    ChannelSelectMenuBuilder,
    ChannelType,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    PermissionsBitField,
    ComponentType
} = require("discord.js");
const { getSettings } = require("../../schema/welcomesystem");

module.exports = {
    name: "welcome",
    description: "Configure the welcome system for this server",
    userPerms: ["Administrator"],

    async run(client, interaction) {
        try {
            await interaction.deferReply({ ephemeral: true });

            const settings = await getSettings(interaction.guild);
            if (!settings.welcome) settings.welcome = {};
            if (!settings.welcome.embed) settings.welcome.embed = {};
            if (!settings.welcome.dm) settings.welcome.dm = { enabled: false, embed: {} };
            await settings.save();

            // Main Menu Function
            const sendMainMenu = async (i) => {
                const embed = new EmbedBuilder()
                    .setColor(client.color || "#FFFFFF")
                    .setTitle("👋 Welcome System Configuration")
                    .setDescription("Please select which welcome system you'd like to configure.")
                    .addFields(
                        { name: "Server Welcome", value: `Status: ${settings.welcome.enabled ? "🟢 Enabled" : "🔴 Disabled"}`, inline: true },
                        { name: "DM Welcome", value: `Status: ${settings.welcome.dm.enabled ? "🟢 Enabled" : "🔴 Disabled"}`, inline: true }
                    );

                const row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("ws_server")
                        .setLabel("Server Welcome")
                        .setStyle(ButtonStyle.Primary),
                    new ButtonBuilder()
                        .setCustomId("ws_dm")
                        .setLabel("DM Welcome")
                        .setStyle(ButtonStyle.Secondary)
                );

                if (i && typeof i.update === 'function') {
                    await i.update({ embeds: [embed], components: [row] });
                } else {
                    await interaction.editReply({ embeds: [embed], components: [row] });
                }
            };

            await sendMainMenu();

            const message = await interaction.fetchReply();
            const collector = message.createMessageComponentCollector({
                filter: (i) => i.user.id === interaction.user.id,
                time: 600000,
            });

            collector.on("collect", async (i) => {
                // Handle Main Menu Buttons
                if (i.customId === "ws_main") {
                    return await sendMainMenu(i);
                }

                if (i.customId === "ws_server") {
                    return await sendServerMenu(i);
                }

                if (i.customId === "ws_dm") {
                    return await sendDMMenu(i);
                }

                // Handle Toggles
                if (i.customId === "ws_toggle_server") {
                    settings.welcome.enabled = !settings.welcome.enabled;
                    await settings.save();
                    return await sendServerMenu(i);
                }

                if (i.customId === "ws_toggle_dm") {
                    settings.welcome.dm.enabled = !settings.welcome.dm.enabled;
                    await settings.save();
                    return await sendDMMenu(i);
                }

                if (i.customId === "ws_toggle_dm_embed") {
                    settings.welcome.dm.embed.enabled = !settings.welcome.dm.embed.enabled;
                    await settings.save();
                    return await sendDMMenu(i);
                }

                // Handle Channel Selection
                if (i.customId === "ws_channel_select") {
                    const channelId = i.values[0];
                    settings.welcome.channel = channelId;
                    await settings.save();
                    return await sendServerMenu(i);
                }

                // Handle Modals via Select Menu
                if (i.customId === "ws_server_options") {
                    const val = i.values[0];
                    return await handleModal(i, val, "server");
                }

                if (i.customId === "ws_dm_options") {
                    const val = i.values[0];
                    return await handleModal(i, val, "dm");
                }
            });

            // Modals cannot be shown after an update, so we handle it before doing i.update
            const handleModal = async (i, type, system) => {
                let title, label, value, customId;

                switch (type) {
                    case "content":
                        title = "Set Message Content";
                        label = "Message Content (Use variables like {user})";
                        value = system === "server" ? settings.welcome.content : settings.welcome.dm.content;
                        customId = `ws_modal_${system}_content`;
                        break;
                    case "title":
                        title = "Set Embed Title";
                        label = "Embed Title";
                        value = system === "server" ? settings.welcome.embed.title : settings.welcome.dm.embed.title;
                        customId = `ws_modal_${system}_title`;
                        break;
                    case "desc":
                        title = "Set Embed Description";
                        label = "Embed Description";
                        value = system === "server" ? settings.welcome.embed.description : settings.welcome.dm.embed.description;
                        customId = `ws_modal_${system}_desc`;
                        break;
                    case "color":
                        title = "Set Embed Color";
                        label = "Hex Color (e.g. #FF0000)";
                        value = system === "server" ? settings.welcome.embed.color : settings.welcome.dm.embed.color;
                        customId = `ws_modal_${system}_color`;
                        break;
                    case "image":
                        title = "Set Embed Image (Banner)";
                        label = "Image URL";
                        value = system === "server" ? settings.welcome.embed.image : settings.welcome.dm.embed.image;
                        customId = `ws_modal_${system}_image`;
                        break;
                    case "thumbnail":
                        title = "Set Embed Thumbnail (Avatar)";
                        label = "Thumbnail URL (or {user_avatar})";
                        value = system === "server" ? settings.welcome.embed.thumbnail : settings.welcome.dm.embed.thumbnail;
                        customId = `ws_modal_${system}_thumbnail`;
                        break;
                }

                const modal = new ModalBuilder()
                    .setCustomId(customId)
                    .setTitle(title.substring(0, 45));

                const input = new TextInputBuilder()
                    .setCustomId("input_value")
                    .setLabel(label.substring(0, 45))
                    .setStyle(type === "content" || type === "desc" ? TextInputStyle.Paragraph : TextInputStyle.Short)
                    .setRequired(false);

                if (value) input.setValue(value);

                const row = new ActionRowBuilder().addComponents(input);
                modal.addComponents(row);

                await i.showModal(modal);

                try {
                    const submitted = await i.awaitModalSubmit({
                        time: 300000,
                        filter: (mi) => mi.user.id === interaction.user.id && mi.customId === customId,
                    });

                    if (!submitted) return;

                    const newValue = submitted.fields.getTextInputValue("input_value");

                    if (system === "server") {
                        if (type === "content") settings.welcome.content = newValue;
                        if (type === "title") settings.welcome.embed.title = newValue;
                        if (type === "desc") settings.welcome.embed.description = newValue;
                        if (type === "color") settings.welcome.embed.color = newValue;
                        if (type === "image") settings.welcome.embed.image = newValue;
                        if (type === "thumbnail") settings.welcome.embed.thumbnail = newValue;
                    } else {
                        if (!settings.welcome.dm.embed) settings.welcome.dm.embed = {};
                        if (type === "content") settings.welcome.dm.content = newValue;
                        if (type === "title") settings.welcome.dm.embed.title = newValue;
                        if (type === "desc") settings.welcome.dm.embed.description = newValue;
                        if (type === "color") settings.welcome.dm.embed.color = newValue;
                        if (type === "image") settings.welcome.dm.embed.image = newValue;
                        if (type === "thumbnail") settings.welcome.dm.embed.thumbnail = newValue;
                    }

                    await settings.save();

                    if (system === "server") {
                        await sendServerMenu(submitted);
                    } else {
                        await sendDMMenu(submitted);
                    }
                } catch (err) {
                    // Modal timeout or error
                }
            };

            const sendServerMenu = async (i) => {
                const embed = new EmbedBuilder()
                    .setColor(client.color || "#FFFFFF")
                    .setTitle("⚙️ Server Welcome Configuration")
                    .setDescription(`Configure what happens when a user joins the server.\n\n**Variables you can use:**\n\`{user}\` = @User\n\`{user_name}\` = User Name\n\`{server_name}\` = Server Name\n\`{server_memberCount}\` = Member Count\n\`{user_avatar}\` = User Avatar\n\`{server_icon}\` = Server Icon`)
                    .addFields(
                        { name: "Status", value: settings.welcome.enabled ? "🟢 Enabled" : "🔴 Disabled", inline: true },
                        { name: "Channel", value: settings.welcome.channel ? `<#${settings.welcome.channel}>` : "Not Set", inline: true },
                        { name: "Content Message", value: settings.welcome.content ? settings.welcome.content.substring(0, 100) : "Not Set" },
                        { name: "Embed Details", value: `**Title:** ${settings.welcome.embed?.title || "None"}\n**Desc:** ${settings.welcome.embed?.description ? "Yes" : "None"}\n**Color:** ${settings.welcome.embed?.color || "None"}\n**Banner:** ${settings.welcome.embed?.image ? "Yes" : "None"}\n**Avatar:** ${settings.welcome.embed?.thumbnail ? "Yes" : "None"}` }
                    );

                const row1 = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("ws_main")
                        .setLabel("⬅️ Back")
                        .setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder()
                        .setCustomId("ws_toggle_server")
                        .setLabel(settings.welcome.enabled ? "Disable Welcome" : "Enable Welcome")
                        .setStyle(settings.welcome.enabled ? ButtonStyle.Danger : ButtonStyle.Success)
                );

                const row2 = new ActionRowBuilder().addComponents(
                    new ChannelSelectMenuBuilder()
                        .setCustomId("ws_channel_select")
                        .setPlaceholder("Select Welcome Channel")
                        .setChannelTypes(ChannelType.GuildText)
                );

                const row3 = new ActionRowBuilder().addComponents(
                    new StringSelectMenuBuilder()
                        .setCustomId("ws_server_options")
                        .setPlaceholder("Edit Configuration Options")
                        .addOptions([
                            { label: "Set Content (Outside Embed)", value: "content", emoji: "📝" },
                            { label: "Set Embed Title", value: "title", emoji: "📌" },
                            { label: "Set Embed Description", value: "desc", emoji: "📄" },
                            { label: "Set Embed Color", value: "color", emoji: "🎨" },
                            { label: "Set Embed Banner (Image)", value: "image", emoji: "🖼️" },
                            { label: "Set Embed Avatar (Thumbnail)", value: "thumbnail", emoji: "👤" },
                        ])
                );

                if (i && typeof i.update === 'function') {
                    await i.update({ embeds: [embed], components: [row1, row2, row3] });
                } else {
                    await interaction.editReply({ embeds: [embed], components: [row1, row2, row3] });
                }
            };

            const sendDMMenu = async (i) => {
                const embed = new EmbedBuilder()
                    .setColor(client.color || "#FFFFFF")
                    .setTitle("⚙️ DM Welcome Configuration")
                    .setDescription(`Configure what message is sent in DM when a user joins.\n\n**Variables you can use:**\n\`{user}\`, \`{user_name}\`, \`{server_name}\`, \`{server_memberCount}\`, \`{user_avatar}\`, \`{server_icon}\``)
                    .addFields(
                        { name: "Status", value: settings.welcome.dm?.enabled ? "🟢 Enabled" : "🔴 Disabled", inline: true },
                        { name: "Use Embed?", value: settings.welcome.dm?.embed?.enabled ? "🟢 Yes" : "🔴 No", inline: true },
                        { name: "Content Message", value: settings.welcome.dm?.content ? settings.welcome.dm.content.substring(0, 100) : "Not Set" },
                        { name: "Embed Details", value: `**Title:** ${settings.welcome.dm?.embed?.title || "None"}\n**Desc:** ${settings.welcome.dm?.embed?.description ? "Yes" : "None"}\n**Color:** ${settings.welcome.dm?.embed?.color || "None"}\n**Banner:** ${settings.welcome.dm?.embed?.image ? "Yes" : "None"}\n**Avatar:** ${settings.welcome.dm?.embed?.thumbnail ? "Yes" : "None"}` }
                    );

                const row1 = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("ws_main")
                        .setLabel("⬅️ Back")
                        .setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder()
                        .setCustomId("ws_toggle_dm")
                        .setLabel(settings.welcome.dm?.enabled ? "Disable DM Welcome" : "Enable DM Welcome")
                        .setStyle(settings.welcome.dm?.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
                    new ButtonBuilder()
                        .setCustomId("ws_toggle_dm_embed")
                        .setLabel(settings.welcome.dm?.embed?.enabled ? "Disable Embed" : "Enable Embed")
                        .setStyle(settings.welcome.dm?.embed?.enabled ? ButtonStyle.Danger : ButtonStyle.Primary)
                );

                const row2 = new ActionRowBuilder().addComponents(
                    new StringSelectMenuBuilder()
                        .setCustomId("ws_dm_options")
                        .setPlaceholder("Edit Configuration Options")
                        .addOptions([
                            { label: "Set Content", value: "content", emoji: "📝" },
                            { label: "Set Embed Title", value: "title", emoji: "📌" },
                            { label: "Set Embed Description", value: "desc", emoji: "📄" },
                            { label: "Set Embed Color", value: "color", emoji: "🎨" },
                            { label: "Set Embed Banner (Image)", value: "image", emoji: "🖼️" },
                            { label: "Set Embed Avatar (Thumbnail)", value: "thumbnail", emoji: "👤" },
                        ])
                );

                if (i && typeof i.update === 'function') {
                    await i.update({ embeds: [embed], components: [row1, row2] });
                } else {
                    await interaction.editReply({ embeds: [embed], components: [row1, row2] });
                }
            };

        } catch (err) {
            console.error("Welcome CMD Error:", err);
            if (!interaction.replied && !interaction.deferred) {
                return interaction.reply({ content: "❌ An error occurred.", ephemeral: true });
            }
        }
    },
};
