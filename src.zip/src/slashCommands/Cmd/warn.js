
const { EmbedBuilder, ApplicationCommandOptionType } = require('discord.js');
module.exports = {
 name:'warn',
 description:'Warn a user',
 options:[
  {name:'user',description:'User to warn',type:ApplicationCommandOptionType.User,required:true},
  {name:'reason',description:'Reason',type:ApplicationCommandOptionType.String,required:true}
 ],
 run: async (client, interaction) => {
   const user = interaction.options.getUser('user');
   const reason = interaction.options.getString('reason');
   const embed = new EmbedBuilder()
    .setTitle('⚠️ Warning')
    .setThumbnail(user.displayAvatarURL({dynamic:true}))
    .addFields(
      {name:'User', value:`${user}`, inline:false},
      {name:'Reason', value:reason, inline:false},
      {name:'Moderator', value:`${interaction.user}`, inline:false}
    )
    .setTimestamp();
   try { await user.send({embeds:[embed]}); } catch(e) {}
   await interaction.reply({embeds:[embed]});
 }
};
