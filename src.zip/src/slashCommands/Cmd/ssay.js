const { EmbedBuilder, ApplicationCommandOptionType } = require('discord.js');

module.exports = {
    name: 'ssay',
    description: 'Send embed message',
    options: [{
        name: 'message',
        description: 'Embed message',
        type: ApplicationCommandOptionType.String,
        required: true
    }],
    run: async (client, interaction) => {
        const message = interaction.options.getString('message');

        const embed = new EmbedBuilder()
            .setColor('#d86ec0')
            .setDescription(message);

        await interaction.reply({
            content: '✅ Embed Sent!',
            ephemeral: true
        });

        return interaction.channel.send({
            embeds: [embed]
        });
    }
};
