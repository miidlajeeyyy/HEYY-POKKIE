
const { ApplicationCommandOptionType, PermissionFlagsBits } = require('discord.js');
module.exports = {
 name:'clearchat',
 description:'Clear messages',
 options:[{name:'amount',description:'Amount of messages',type:ApplicationCommandOptionType.Integer,required:true}],
 run: async (client, interaction) => {
   if(!interaction.memberPermissions.has(PermissionFlagsBits.ManageMessages))
    return interaction.reply({content:'You need Manage Messages permission.',ephemeral:true});
   const amount = interaction.options.getInteger('amount');
   if(amount < 1 || amount > 100) return interaction.reply({content:'Amount must be between 1 and 100.',ephemeral:true});
   await interaction.channel.bulkDelete(amount,true);
   await interaction.reply({content:`✅ Deleted ${amount} messages.`,ephemeral:true});
 }
};
