/** @format
 *
 * Pookie By paku
 * © 2026 Paku Development
 *
 */

const {
  EmbedBuilder,
  MessageFlags,
  CommandInteraction,
  Client,
  ButtonBuilder,
  ActionRowBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
} = require("discord.js");

module.exports = {
  name: "help",
  description: "Help Menu!",
  userPrams: [],
  botPrams: ["EMBED_LINKS"],

run: async (client, interaction, prefix) => {
    await interaction.deferReply({
      ephemeral: false,
    });

    const HELP_BANNER = client.config?.links?.BG || client.config?.links?.arrkiii || "";

    const PAKU = await client.users.fetch("1130416772168818748");

    const embed = new client.embed()
      .setColor("#FD34AC")
      .d(
        `Hey ${interaction.member}, I'm ${client.user}!
- **A complete Music Bot for your server**
- **Providing you the best quality music**`,
      )
      .addFields(
  {
    name: "**__Main Features__**",
    value: `
>  <:antinuke:1514974023241437184> **Antinuke**
>  <:automod:1514974230373204083> **Automod**
>  <:Config:1514974500943302716> **Config**
>  <:fun:1514974686885187625> **Fun**
>  <:kb_information:1514974875415089212> **Information**
>  <:moderation1:1514975491390574683> **Moderation**
>  <:music:1514975798652698695> **Music**
>  <:profile:1514976136264679434> **Profile**
>  <a:utility:1514976559482802256> **Utility**
>  <:fun:1514974686885187625> **Voice**
    `,
    inline: true,
  },
  {
    name: "**__Extra Features__**",
    value: `
>  **Extra**
>  **Pfps**
>  **Playlists**
>  **Role**
>  **Ticket** 
>  **Verify** 
>  **Generate** 
    `,
    inline: true,
  }
)
      .img(HELP_BANNER)
      .thumb(HELP_BANNER)
      .setFooter({
        text: "Pookie<3• ",
        iconURL: HELP_BANNER,
      });

    const buttonRow = new ActionRowBuilder().addComponents(
      new client.button().s("home", "", client.emoji.home),
    );

    const commandCategories = [
      {
        label: "Antinuke",
        value: "antinuke",
        description: "Get all Antinuke commands",
        emoji: `${client.emoji.antinuke}`,
      },
        {
        label: "Automod",
        value: "automod",
        description: "Get all Automod commands",
        emoji: `<:meko:1389892185754959912>`,
      },
      {
        label: "Config",
        value: "config",
        description: "Get all Config commands",
        emoji: `${client.emoji.config}`,
      },
      {
        label: "Extra",
        value: "extra",
        description: "Get all Extra commands",
        emoji: `${client.emoji.extra}`,
      },
      {
        label: "Fun",
        value: "fun",
        description: "Get all Fun commands",
        emoji: `${client.emoji.fun}`,
      },
      {
        label: "Information",
        value: "information",
        description: "Get all Information commands",
        emoji: `${client.emoji.information}`,
      },
      {
        label: "Moderation",
        value: "moderation",
        description: "Get all Moderation commands",
        emoji: `${client.emoji.moderation}`,
      },
      {
        label: "Music",
        value: "music",
        description: "Get all Music commands",
        emoji: `${client.emoji.music}`,
      },
      {
        label: "Pfp",
        value: "pfp",
        description: "Get all Pfps commands",
        emoji: `${client.emoji.pfp}`,
      },
      {
        label: "Playlist",
        value: "playlist",
        description: "Get all Playlist commands",
        emoji: `${client.emoji.playlist}`,
      },
      {
        label: "Profile",
        value: "profile",
        description: "Get all Profile commands",
        emoji: `${client.emoji.profile}`,
      },
      {
        label: "Role",
        value: "role",
        description: "Get all Role commands",
        emoji: `${client.emoji.role}`,
      },
      {
        label: "Utility",
        value: "utility",
        description: "Get all Utility commands",
        emoji: `${client.emoji.utility}`,
      },
      {
        label: "Voice",
        value: "voice",
        description: "Get all Voice commands",
        emoji: `${client.emoji.voice}`,
      },
      {
        label: "Ticket",
        value: "ticket",
        description: "Get all Ticket Commands",
        emoji: `${client.emoji.ticket}`,
      },
        {
        label: "Verify",
        value: "verify",
        description: "Get all Verify commands",
        emoji: `${client.emoji.tick}`,
      },
        {
        label: "Counting",
        value: "counting",
        description: "Get all Counting commands",
        emoji: `${client.emoji.counting}`,
      },
         {
        label: "Generate",
        value: "generate",
        description: "Get all Generate commands",
        emoji: `${client.emoji.plus}`,
      },
    ];

    const mainMenu = new ActionRowBuilder().addComponents(
  new StringSelectMenuBuilder()
    .setCustomId("help_main")
    .setPlaceholder("Main Commands")
    .addOptions([
      { label: "Antinuke", value: "antinuke", emoji: client.emoji.antinuke },
      { label: "Automod", value: "automod", emoji: "<:meko:1414560812353327124>" },
      { label: "Config", value: "config", emoji: client.emoji.config },
      { label: "Fun", value: "fun", emoji: client.emoji.fun },
      { label: "Information", value: "information", emoji: client.emoji.information },
      { label: "Moderation", value: "moderation", emoji: client.emoji.moderation },
      { label: "Music", value: "music", emoji: client.emoji.music },
      { label: "Utility", value: "utility", emoji: client.emoji.utility },
      { label: "Voice", value: "voice", emoji: client.emoji.voice },
    ])
);
const extraMenu = new ActionRowBuilder().addComponents(
  new StringSelectMenuBuilder()
    .setCustomId("help_extra")
    .setPlaceholder("Extra Commands")
    .addOptions([
      { label: "Extra", value: "extra", emoji: client.emoji.extra },
      { label: "Pfp", value: "pfp", emoji: client.emoji.pfp },
      { label: "Playlist", value: "playlist", emoji: client.emoji.playlist },
      { label: "Profile", value: "profile", emoji: client.emoji.profile },
      { label: "Role", value: "role", emoji: client.emoji.role },
      { label: "Ticket", value: "ticket", emoji: client.emoji.ticket },
      { label: "Verify", value: "verify", emoji: client.emoji.tick },
      { label: "Generate", value: "generate", emoji: client.emoji.plus },
    ])
);


    const msg = await interaction.editReply({
      embeds: [embed],
      components: [mainMenu, extraMenu],
    });

    const collector = interaction.channel.createMessageComponentCollector({
      filter: (b) => {
        if (b.user.id === interaction.user.id) return true;
        else
          return b
            .reply({
              content: `${client.emoji.cross} | That's not your session run : \`${prefix}help\` to create your own.`,
              ephemeral: true,
            })
            .catch(() => {});
      },
      time: 60000 * 5,
      idle: 30e3,
    });

    collector.on("collect", async (i) => {
      if (i.isButton() && i.customId === "home") {
        return i.update({
          embeds: [embed],
          components: [mainMenu, extraMenu],
        });
      } else if (i.isStringSelectMenu()) {
        const selectedCategory = i.values[0];
        const categoryCommands = client.commands
          .filter((cmd) => cmd.category?.toLowerCase() === selectedCategory)
          .map((cmd) => `\`${cmd.name}\``);

        const categoryEmbed = new client.embed()
          .d(
            `${
              categoryCommands.join(", ") ||
              "No commands found for this category."
            }`,
          )
          .t(
            `${client.emoji[selectedCategory]} ${
              selectedCategory.charAt(0).toUpperCase() +
              selectedCategory.slice(1)
            } Commands`,
          )
          .setColor("#FD34AC")
          .setFooter({
            text: `Total ${categoryCommands.length} commands • Pookie<3`,
            iconURL: HELP_BANNER,
          })
          .img(HELP_BANNER || client.config.links.BG || client.config.links.arrkiii);

        await i.update({
          embeds: [categoryEmbed],
          components: [mainMenu, extraMenu, buttonRow],
        });
      }
    });

    collector.on("end", () => {
      msg.edit({ components: [] });
    });
  },
};
